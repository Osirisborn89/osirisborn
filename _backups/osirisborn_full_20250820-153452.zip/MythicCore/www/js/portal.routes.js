(function () {
  function appNode(){
    let el = document.getElementById("app");
    if(!el){
      el = document.createElement("main");
      el.id = "app"; el.className = "wrap";
      document.body.appendChild(el);
      console.warn("[router] created #app automatically");
    }
    return el;
  }

  function renderHome(){
    const app = appNode();
    app.innerHTML = `
      <section class="view">
        <h1>Welcome</h1>
        <div class="card">
          <p class="muted">Jump into learning or chill in the lounge.</p>
          <p><a class="btn primary" href="#/learn">Go to Learning →</a></p>
        </div>
      </section>`;
  }

  function renderLearn(){
    const app = appNode();
    app.innerHTML = `
      <section class="view">
        <h1>Learning</h1>
        <div class="grid">
          <a class="tile" href="#/learn/languages">
            <strong>Language Lessons</strong>
            <div class="muted">Python, JavaScript…</div>
          </a>
          <a class="tile" href="#/lounge">
            <strong>Downtime Lounge</strong>
            <div class="muted">Break time</div>
          </a>
        </div>
      </section>`;
  }

  function renderLanguages(){
    const app = appNode();
    app.innerHTML = `
      <section class="view">
        <h1>Language Lessons</h1>
        <p class="muted"><a href="#/learn">← Back to Learning</a></p>
        <div class="grid">
          <a class="tile" href="#/learn/languages/python">
            <strong>Python</strong>
            <div class="muted">Beginner → Job-ready</div>
          </a>
          <a class="tile" href="#/learn/languages/javascript">
            <strong>JavaScript</strong>
            <div class="muted">Coming soon</div>
          </a>
        </div>
      </section>`;
  }

  async function renderPython(){
    const app = appNode();
    let data = null;
    try{
      let r = await fetch("/api/lessons/tracks.json", {headers:{Accept:"application/json"}});
      if(!r.ok) throw new Error(String(r.status));
      data = await r.json();
    }catch(_){
      try{
        let r2 = await fetch("/api/lessons/tracks", {headers:{Accept:"application/json"}});
        if(!r2.ok) throw new Error(String(r2.status));
        data = await r2.json();
      }catch(e){
        // Friendly stub
        data = {
          id:"python-mastery",
          title:"Python Mastery",
          modules:[
            { title:"Foundations", lessons:["py-01-01","py-01-02","py-01-03"] },
            { title:"Core Syntax", lessons:["py-02-01","py-02-02","py-02-03"] },
          ]
        };
      }
    }

    const modules = (data?.modules||[]).map(m => `
      <section class="card">
        <div style="display:flex;justify-content:space-between;align-items:center;">
          <h2>${m.title}</h2><span class="badge">MVP</span>
        </div>
        <ul style="margin:6px 0 0 1.2rem;">
          ${(m.lessons||[]).map(id=>`<li>${id}</li>`).join("")}
        </ul>
      </section>
    `).join("");

    app.innerHTML = `
      <section class="view">
        <h1>Python</h1>
        <p class="muted"><a href="#/learn/languages">← Back to Languages</a></p>
        <div class="grid">${modules}</div>
      </section>`;
  }

  function renderJS(){
    const app = appNode();
    app.innerHTML = `
      <section class="view">
        <h1>JavaScript</h1>
        <div class="card">Curriculum coming soon.</div>
        <p class="muted"><a href="#/learn/languages">← Back to Languages</a></p>
      </section>`;
  }

  function renderLounge(){
    const app = appNode();
    app.innerHTML = `
      <section class="view">
        <h1>Downtime Lounge</h1>
        <div class="card">Coming soon.</div>
      </section>`;
  }

  function apply(){
    const h = (location.hash || "#/home").replace(/\/+$/,"");

    // Back-compat: old "#/learn/coding" should land on Languages
    if(h.startsWith("#/learn/coding")) return renderLanguages();

    if(h.startsWith("#/learn/languages/python")) return renderPython();
    if(h.startsWith("#/learn/languages/javascript")) return renderJS();
    if(h.startsWith("#/learn/languages")) return renderLanguages();

    if(h.startsWith("#/learn"))  return renderLearn();
    if(h.startsWith("#/lounge")) return renderLounge();
    return renderHome();
  }

  window.addEventListener("hashchange", () => requestAnimationFrame(apply));
  if(document.readyState === "loading"){
    document.addEventListener("DOMContentLoaded", () => requestAnimationFrame(apply));
  } else {
    requestAnimationFrame(apply);
  }
})();
