(function(){
  try{
    var h=(location.hash||"").replace(/\/+$/,"");
    if(!h || h==="#" || h==="#/"){ location.hash="#/home"; }
    window.dispatchEvent(new CustomEvent("portal:ready"));
    console.log("LESS-016 portal booted");
  }catch(e){ console.warn("boot.portal error", e); }
})();
