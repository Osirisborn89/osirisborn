# tools\Fix-Portal-Assets.ps1
[CmdletBinding()]
param(
  [switch]$RestartServer,
  [switch]$NoPause
)
$ErrorActionPreference = 'Stop'

try {
  $root = (Get-Location).Path
  $www  = Join-Path $root 'MythicCore\www'
  $js   = Join-Path $www  'js'
  New-Item -ItemType Directory -Force $www | Out-Null
  New-Item -ItemType Directory -Force $js  | Out-Null

  # --- Write required assets ---
  Set-Content -Encoding UTF8 -Path (Join-Path $www 'portal.css') -Value @"
:root{--bg:#0f1220;--panel:#171a2b;--text:#e7ecf5}
html,body{height:100%}
body{margin:0;background:var(--bg);color:var(--text)}
#osb-nav{border-bottom:1px solid #252c47}
"@

  Set-Content -Encoding UTF8 -Path (Join-Path $www 'portal.kill.css') -Value @"
"@

  Set-Content -Encoding UTF8 -Path (Join-Path $www 'runner.css') -Value @"
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
"@

  Set-Content -Encoding UTF8 -Path (Join-Path $js 'boot.portal.js') -Value @"
(function(){
  try{
    var h=(location.hash||"").replace(/\/+$/,"");
    if(!h || h==="#" || h==="#/home"){ location.hash="#/lessons"; }
    window.dispatchEvent(new CustomEvent("portal:ready"));
    console.log("LESS-016 portal booted");
  }catch(e){ console.warn("boot.portal error",e); }
})();
"@

  Set-Content -Encoding UTF8 -Path (Join-Path $js 'sw-register.js') -Value @"
(() => {
  try {
    const url = new URL(location.href);
    const swOff = url.searchParams.get("sw")==="off";
    const isLocal = (location.hostname==="127.0.0.1" || location.hostname==="localhost");
    if (swOff || isLocal) {
      console.log("[SW] dev mode: service worker disabled");
      if ("serviceWorker" in navigator) {
        navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister()));
      }
      return;
    }
    if ("serviceWorker" in navigator) {
      window.addEventListener("load", () => {
        navigator.serviceWorker.register("/sw.js")
          .then(reg => console.log("[SW] registered ok; scope=", reg.scope))
          .catch(err => console.warn("[SW] registration failed", err));
      });
    }
  } catch(e){ console.warn("[SW] script error", e); }
})();
"@

  # --- Update index.html ---
  $idx  = Join-Path $www 'index.html'
  if (-not (Test-Path $idx)) { throw "index.html not found at $idx" }
  $ver  = Get-Date -Format 'yyyyMMddHHmmss'
  $html = Get-Content $idx -Raw

  # remove broken =timestamp tags & any legacy xp-panel asset includes & prior portal/sw tags
  $html = [regex]::Replace($html,'(?is)\s*<link[^>]+href=["'']\s*/?=\d+[^"'']*["''][^>]*>\s*','')
  $html = [regex]::Replace($html,'(?is)\s*<script[^>]+src=["'']\s*/?=\d+[^"'']*["'']\s*>\s*</script>\s*','')
  $html = [regex]::Replace($html,'(?is)\s*<(link|script)[^>]+?(xp-panel\.(css|js)|portal(\.kill)?\.css|js/(sw-register|boot\.portal)\.js)[^>]*>(\s*</script>)?\s*','')

  # inject portal CSS + slim "hide legacy widgets" so first paint matches new UI
  $headBlock = @"
  <link rel='stylesheet' href='portal.css?v=$ver' />
  <link rel='stylesheet' href='portal.kill.css?v=$ver' />
  <!-- OSB:HOME-SLIM -->
  <style id='osb-home-slim'>
    #xp-panel,#xp-dev{display:none !important;}
    #missions,#missions *{display:none !important;}
    #btn-add,#btn-refresh,#btn-backup,#btn-restore{display:none !important;}
  </style>
"@
  if ($html -match '</head>') { $html = $html -replace '</head>', "$headBlock`r`n</head>" } else { $html = "$headBlock`r`n$html" }

  # inject SW + boot.portal (versioned) at body end
  $bodyBlock = @"
  <script src='js/sw-register.js?v=$ver'></script>
  <script src='js/boot.portal.js?v=$ver'></script>
"@
  if ($html -match '</body>') { $html = $html -replace '</body>', "$bodyBlock`r`n</body>" } else { $html = "$html`r`n$bodyBlock" }

  $html = [regex]::Replace($html,"(\r?\n){3,}","`r`n`r`n")
  Set-Content -Encoding UTF8 -Path $idx -Value $html

  # verify files exist
  $expect = @(
    (Join-Path $www 'portal.css'),
    (Join-Path $www 'portal.kill.css'),
    (Join-Path $www 'runner.css'),
    (Join-Path $js  'boot.portal.js'),
    (Join-Path $js  'sw-register.js')
  )
  $missing = $expect | Where-Object { -not (Test-Path $_) }
  if ($missing) { throw "Missing: $($missing -join ', ')" }

  Write-Host "✓ Rewrote portal assets and index.html (v=$ver)" -ForegroundColor Green

  if ($RestartServer) {
    # kill listener on :7780 (if any), then reset server and open ONE tab
    $listener = Get-NetTCPConnection -LocalPort 7780 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
    if ($listener) { Stop-Process -Id $listener.OwningProcess -Force -ErrorAction SilentlyContinue }
    & (Join-Path $root 'tools\Reset-Server.ps1')
    $b = Get-Date -Format 'yyyyMMddHHmmss'
    Start-Process ("http://127.0.0.1:7780/?sw=off&bust=$b#/lessons")
    Write-Host "Open: http://127.0.0.1:7780/?sw=off&bust=$b#/lessons" -ForegroundColor Cyan
  }
}
catch {
  Write-Host "ERROR: $($_.Exception.Message)" -ForegroundColor Red
  throw
}
finally {
  if (-not $NoPause) { Read-Host "Done. Press Enter to close" | Out-Null }
}
