param([int]$Port=7780,[switch]$Debug)
pwsh -NoProfile -File .\tools\Stop-Server.ps1 -Port $Port | Out-Null
pwsh -NoProfile -ExecutionPolicy Bypass -File .\tools\Run-Server.ps1 -Port $Port -Debug:$Debug
# OSB: BEGIN single-open
$ver = Get-Date -Format 'yyyyMMddHHmmss'
Start-Process ("http://127.0.0.1:7780/?sw=off&bust=$ver#/lessons")
# OSB: END single-open
