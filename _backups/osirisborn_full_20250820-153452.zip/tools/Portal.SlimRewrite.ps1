# tools\Portal.SlimRewrite.ps1
[CmdletBinding()]
param(
  [switch]$RestartServer,
  [switch]$NoPause
)
$ErrorActionPreference = 'Stop'

$root = (Get-Location).Path
$www  = Join-Path $root 'MythicCore\www'
$js   = Join-Path $www  'js'
New-Item -ItemType Directory -Force $www | Out-Null
New-Item -ItemType Directory -Force $js  | Out-Null

# Ensure required portal assets exist (idempotent small stubs)
Set-Content -Encoding UTF8 -Path (Join-Path $www 'portal.css') -Value @"
:root{--bg:#0f1220;--panel:#171a2b;--text:#e7ecf5}
html,body{height:100%}
body{margin:0;background:var(--bg);color:var(--text)}
#osb-nav{border-bottom:1px solid #252c47}
"@
Set-Content -Encoding UTF8 -Path (Join-Path $www 'portal.kill.css') -Value @"
"@
Set-Content -Encoding UTF8 -Path (Join-Path $www 'runner.css') -Value @"
.mono{font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace}
"@
Set-Content -Encoding UTF8 -Path (Join-Path $js 'boot.portal.js') -Value @"
(function(){
  try{
    var h=(location.hash||"").replace(/\/+$/,"");
    if(!h || h==="#" || h==="#/home"){ location.hash="#/lessons"; }
    window.dispatchEvent(new CustomEvent("portal:ready"));
    console.log("LESS-016 portal booted");
  }catch(e){ console.warn("boot.portal error",e); }
})();
"@
Set-Content -Encoding UTF8 -Path (Join-Path $js 'sw-register.js') -Value @"
(()=>{try{
  const url=new URL(location.href);
  const swOff=url.searchParams.get('sw')==='off';
  const isLocal=(location.hostname==='127.0.0.1'||location.hostname==='localhost');
  if(swOff||isLocal){
    console.log('[SW] dev mode: service worker disabled');
    if('serviceWorker' in navigator){
      navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister()));
    }
    return;
  }
  if('serviceWorker' in navigator){
    window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js')
      .then(reg=>console.log('[SW] registered ok; scope=',reg.scope))
      .catch(err=>console.warn('[SW] registration failed',err)));
  }
}catch(e){console.warn('[SW] script error',e);}})();
"@

# Rewrite index.html to a slim shell (remove legacy DOM + legacy script tags)
$idx = Join-Path $www 'index.html'
if(!(Test-Path $idx)){ throw "index.html not found: $idx" }

$ver  = Get-Date -Format 'yyyyMMddHHmmss'
$raw  = Get-Content $idx -Raw

# Backup legacy once
$bak = Join-Path $www '_legacy-dashboard.html'
if (!(Test-Path $bak)) { $raw | Set-Content -Encoding UTF8 $bak }

# Strip known-problem assets and legacy blocks
$raw = [regex]::Replace($raw,'(?is)\s*<link[^>]+href=["'']\s*/?=\d+[^"'']*["''][^>]*>\s*','')                # bad =123 tags
$raw = [regex]::Replace($raw,'(?is)\s*<script[^>]+src=["'']\s*/?=\d+[^"'']*["'']\s*>\s*</script>\s*','')      # bad =123 scripts
$raw = [regex]::Replace($raw,'(?is)\s*<(?:link|script)[^>]+?(xp-panel\.(?:css|js)|js/(?:postrun\.polyfill|lesson\.actions|lesson\.autobind)\.js)[^>]*>(?:\s*</script>)?\s*','')
$raw = [regex]::Replace($raw,'(?is)\s*<(?:link|script)[^>]+?(portal(?:\.kill)?\.css|js/(?:sw-register|boot\.portal)\.js)[^>]*>(?:\s*</script>)?\s*','')

# Replace <body> ... </body> with slim markup
$slimBody = @"
<body>
  <header id="osb-nav" style="padding:10px 16px;border-bottom:1px solid #252c47">
    <nav style="display:flex;gap:12px;align-items:center;">
      <a id="nav-home" href="#/lessons" style="text-decoration:none;">Lessons</a>
    </nav>
  </header>
  <main id="app"></main>
  <div id="toast"></div>
</body>
"@
$raw = [regex]::Replace($raw,'(?is)<body\b.*?</body>',$slimBody)

# Ensure minimal HEAD with portal assets + hide-legacy safety
$headInject = @"
  <link rel='stylesheet' href='portal.css?v=$ver' />
  <link rel='stylesheet' href='portal.kill.css?v=$ver' />
  <!-- OSB:HOME-SLIM -->
  <style id='osb-home-slim'>
    #xp-panel,#xp-dev{display:none !important;}
    #missions,#missions *{display:none !important;}
    #btn-add,#btn-refresh,#btn-backup,#btn-restore{display:none !important;}
  </style>
"@
if ($raw -match '</head>') { $raw = $raw -replace '</head>', "$headInject`r`n</head>" } else { $raw = "$headInject`r`n$raw" }

# Add only the two canonical scripts at the end of BODY
$bodyInject = @"
  <script src='js/sw-register.js?v=$ver'></script>
  <script src='js/boot.portal.js?v=$ver'></script>
"@
$raw = $raw -replace '</body>', "$bodyInject`r`n</body>"

# Tidy extra blanks
$raw = [regex]::Replace($raw,"(\r?\n){3,}","`r`n`r`n")
Set-Content -Encoding UTF8 -Path $idx -Value $raw
Write-Host "✓ Slim shell applied to index.html (v=$ver)" -ForegroundColor Green

# Quick self-checks
$served = Invoke-WebRequest http://127.0.0.1:7780/ -UseBasicParsing
$ok1 = [regex]::IsMatch($served.Content,'js/boot\.portal\.js\?v=\d+')
$ok2 = -not [regex]::IsMatch($served.Content,'id="xp-panel"')
Write-Host ("• Served HTML has boot.portal.js?v: {0}" -f $ok1)
Write-Host ("• Legacy dashboard removed: {0}" -f $ok2)

if ($RestartServer) {
  $listener = Get-NetTCPConnection -LocalPort 7780 -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
  if ($listener) { Stop-Process -Id $listener.OwningProcess -Force -ErrorAction SilentlyContinue }
  & (Join-Path $root 'tools\Reset-Server.ps1')
  $b = Get-Date -Format 'yyyyMMddHHmmss'
  Start-Process ("http://127.0.0.1:7780/?sw=off&bust=$b#/lessons")
  Write-Host "Open: http://127.0.0.1:7780/?sw=off&bust=$b#/lessons" -ForegroundColor Cyan
}

if (-not $NoPause) { Read-Host "Done. Press Enter to close" | Out-Null }
