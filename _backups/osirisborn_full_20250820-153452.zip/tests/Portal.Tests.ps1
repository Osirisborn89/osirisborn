$ErrorActionPreference='Stop'

BeforeAll {
  & "$PSScriptRoot/../tools/Reset-Server.ps1" | Out-Null
  Start-Sleep -Milliseconds 250
}

Describe "Purple portal shell" {
  It "serves canonical assets (200 and not HTML)" {
    foreach($u in @(
      'http://127.0.0.1:7780/portal.css',
      'http://127.0.0.1:7780/js/portal.routes.js',
      'http://127.0.0.1:7780/js/sw-register.js',
      'http://127.0.0.1:7780/js/boot.portal.js',
      'http://127.0.0.1:7780/js/postrun.polyfill.js',
      'http://127.0.0.1:7780/js/lesson.actions.js',
      'http://127.0.0.1:7780/js/lesson.autobind.js'
    )){
      $r = Invoke-WebRequest $u -UseBasicParsing
      $r.StatusCode | Should -Be 200
      ($r.Content.TrimStart().StartsWith('<')) | Should -BeFalse
    }
  }

  It "index.html is the purple shell (not legacy, no =timestamp bug)" {
    $html = (Invoke-WebRequest "http://127.0.0.1:7780/" -UseBasicParsing).Content
    $html | Should -Match 'id="osb-nav"'
    $html | Should -Match 'id="view-home"'
    $html | Should -Match 'js/portal\.routes\.js\?v=\d+'
    $html | Should -Not -Match 'xp-panel'

    # Here-string avoids quote escaping; tests for the bad /=123 timestamp script tags
    $rxBad = @"
src=["']/=\d+
"@
    $html | Should -Not -Match $rxBad
  }
}
