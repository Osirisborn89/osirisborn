See MASTER_BLUEPRINT.md → Cyber Range / Red vs Blue / CTF / Spectral Trials. v0 simulated targets → v1 containerized labs. Safe, offline, resettable.
