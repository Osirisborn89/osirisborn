See MASTER_BLUEPRINT.md → Toolkit Vault (coding/red/blue/OSINT/AI), search, unlocks, sandboxed runners.
