See MASTER_BLUEPRINT.md → Curriculum Hub + Curriculum Page System + Multi-Language Tracks. Lesson manifests, split view, checklists, capstones.
