See MASTER_BLUEPRINT.md → Downtime Lounge: playlists, retro games, break timers, sandboxed browser, mood tracking.
