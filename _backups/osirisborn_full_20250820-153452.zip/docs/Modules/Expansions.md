See MASTER_BLUEPRINT.md → Expansion Modules: Quantum Lab, Darknet Simulator, Mission Generator, Memory Palace, Spectral Trials, Threat Pulse, VPN/Firewall toolkit, Legacy Capsules.
