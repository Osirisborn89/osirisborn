See MASTER_BLUEPRINT.md → Lore & Mystery System. Encrypted scrolls, UI secrets, ARG-style safe trails.
