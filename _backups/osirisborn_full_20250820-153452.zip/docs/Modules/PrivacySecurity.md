See MASTER_BLUEPRINT.md → Privacy & Security Infrastructure. Offline-first, encryption, panic switch, signed packs.
