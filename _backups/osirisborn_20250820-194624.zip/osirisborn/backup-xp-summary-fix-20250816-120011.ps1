#requires -Version 5.1
[Console]::OutputEncoding = [Text.Encoding]::UTF8

# ---- Resolve important paths (robust, balanced) ----
$ScriptRoot = $null
try {
  if ($PSScriptRoot) { $ScriptRoot = $PSScriptRoot }
  elseif ($PSCommandPath) { $ScriptRoot = (Split-Path -Parent $PSCommandPath) }
  elseif ($MyInvocation -and $MyInvocation.MyCommand -and $MyInvocation.MyCommand.Path) {
    $ScriptRoot = (Split-Path -Parent $MyInvocation.MyCommand.Path)
  }
} catch {}
if (-not $ScriptRoot) {
  try { $ScriptRoot = (Split-Path -Parent $PSCommandPath) } catch { $ScriptRoot = "." }
}

$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'

# ---- Try optional modules; fall back to built-ins if they’re missing ----
try { Import-Module (Join-Path $Modules 'Osirisborn.Store.psm1')    -ErrorAction Stop } catch {}
try { Import-Module (Join-Path $Modules 'Osirisborn.XP.psm1')       -ErrorAction Stop } catch {}
try { Import-Module (Join-Path $Modules 'Osirisborn.Missions.psm1') -ErrorAction Stop } catch {}

# ---- Store fallbacks (Initialize/Get/Save) ----
if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      if (-not (Test-Path $DataDir)) { New-Item -ItemType Directory -Path $DataDir -Force | Out-Null }
      $storePath = Join-Path $DataDir 'store.plasma'
      if (-not (Test-Path $storePath)) {
        '{"user":{"alias":"Osirisborn"},"xp":{"events":[]},"missions":{"catalog":{},"completed":[]},"meta":{"xpLog":[]},"settings":{"dailyGoal":300,"notify":true}}' |
          Set-Content -Path $storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}
if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $storePath = Join-Path $DataDir 'store.plasma'
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json -Depth 64
    } catch {
      $obj = ConvertFrom-Json '{"user":{"alias":"Osirisborn"},"xp":{"events":[]},"missions":{"catalog":{},"completed":[]},"meta":{"xpLog":[]},"settings":{"dailyGoal":300,"notify":true}}'
    }
    if (-not $obj.xp)       { $obj | Add-Member -NotePropertyName xp       -NotePropertyValue ([pscustomobject]@{ events=@() }) -Force }
    if (-not $obj.meta)     { $obj | Add-Member -NotePropertyName meta     -NotePropertyValue ([pscustomobject]@{ xpLog=@()  }) -Force }
    if (-not $obj.settings) { $obj | Add-Member -NotePropertyName settings -NotePropertyValue ([pscustomobject]@{ dailyGoal=300; notify=$true }) -Force }
    return $obj
  }
}
if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $storePath = Join-Path $DataDir 'store.plasma'
    Initialize-OsStore | Out-Null
    $Store | ConvertTo-Json -Depth 64 | Set-Content -Path $storePath -Encoding UTF8
    return $true
  }
}

# ---- XP fallbacks (Get/Add) ----
if (-not (Get-Command Get-OsXP -ErrorAction SilentlyContinue)) {
  function Get-OsXP {
    $s = Get-OsStore -Ensure
    $total = 0
    if ($s.meta -and $s.meta.xpLog) { foreach ($e in $s.meta.xpLog) { $total += [int]$e.delta } }
    $rank = "Initiate"
    $progress = [int]([math]::Round(($total % 100) / 100 * 100))
    [pscustomobject]@{ XP = $total; Rank = $rank; ProgressPct = $progress }
  }
}
if (-not (Get-Command Add-OsXP -ErrorAction SilentlyContinue)) {
  function Add-OsXP {
    param([Parameter(Mandatory=$true)][int]$Amount, [string]$Reason="")
    $s = Get-OsStore -Ensure
    $now = Get-Date
    if (-not $s.meta)      { $s | Add-Member -NotePropertyName meta  -NotePropertyValue ([pscustomobject]@{ xpLog=@() }) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member -NotePropertyName xpLog -NotePropertyValue @() -Force }
    $total = 0; foreach ($e in $s.meta.xpLog) { $total += [int]$e.delta }
    $total += $Amount
    $entry = [pscustomobject]@{ at=$now.ToString("o"); delta=$Amount; reason=$Reason; total=$total; rank="Initiate" }
    $s.meta.xpLog = @($s.meta.xpLog + $entry)
    Save-OsStore -Store $s | Out-Null
    return $entry
  }
}

# ---- Helpers ----
function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $json  = $obj | ConvertTo-Json -Depth 60
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.StatusCode = $status
    $res.ContentType = 'application/json; charset=utf-8'
    $res.ContentLength64 = $bytes.Length
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.ContentLength64 = $bytes.Length
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 20 } catch { return @{} }
}

# ---- XP summary (used by /xp.json) ----
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  @($true, [pscustomobject]@{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  })
}

# ---- Lessons helpers ----
function Get-LessonsSummary {
  $currPath = Join-Path $DataDir 'curriculum.json'
  $progPath = Join-Path $DataDir 'progress.lessons.json'
  $tracks=@()
  if (Test-Path $currPath) {
    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    foreach ($t in $curr.tracks) {
      $lessonsCount = 0
      foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
      $completed = 0
      if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
        $completed = @($prog.$($t.id).completedLessons).Count
      }
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      $tracks += [pscustomobject]@{
        id        = $t.id
        title     = $t.title
        lessons   = $lessonsCount
        completed = $completed
        progress  = $progress
      }
    }
  }
  [pscustomobject]@{ totalTracks = @($tracks).Count; tracks = $tracks }
}
function Get-LessonsTrack([string]$TrackId) {
  $currPath = Join-Path $DataDir 'curriculum.json'
  $progPath = Join-Path $DataDir 'progress.lessons.json'
  if (-not (Test-Path $currPath)) { return $null }
  $curr = Get-Content $currPath -Raw | ConvertFrom-Json
  $track = $curr.tracks | Where-Object { $_.id -eq $TrackId }
  if (-not $track) { return $null }
  $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
  $completedSet = @{}
  if ($prog -and ($prog.PSObject.Properties.Name -contains $TrackId)) {
    foreach ($lid in $prog.$TrackId.completedLessons) { $completedSet[$lid] = $true }
  }
  $total = 0; $done = 0
  foreach ($m in $track.modules) {
    foreach ($l in $m.lessons) {
      $total++
      if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true  -Force }
      else                                  {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
    }
  }
  $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }
  [pscustomobject]@{
    id       = $track.id
    title    = $track.title
    progress = $progress
    modules  = $track.modules
    totals   = @{ lessons = $total; completed = $done }
  }
}
function Complete-Lesson([string]$TrackId, [string]$LessonId) {
  $currPath = Join-Path $DataDir 'curriculum.json'
  $progPath = Join-Path $DataDir 'progress.lessons.json'
  if (-not (Test-Path $currPath)) { return @{ error="no-curriculum" } }
  $curr = Get-Content $currPath -Raw | ConvertFrom-Json
  $track = $curr.tracks | Where-Object { $_.id -eq $TrackId }
  if (-not $track) { return @{ error="track-not-found" } }

  $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { ConvertFrom-Json '{}' }
  if (-not ($prog.PSObject.Properties.Name -contains $TrackId)) {
    $prog | Add-Member -NotePropertyName $TrackId -NotePropertyValue ([pscustomobject]@{ completedLessons=@() }) -Force
  }
  $completed = @($prog.$TrackId.completedLessons)
  if ($completed -contains $LessonId) {
    $total = 0; foreach ($m in $track.modules) { $total += @($m.lessons).Count }
    $done  = $completed.Count
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }
    return @{ status="exists"; trackId=$TrackId; lessonId=$LessonId; awarded=0; totals=@{lessons=$total;completed=$done}; progress=$progress }
  }

  # mark complete
  $prog.$TrackId.completedLessons = @($completed + $LessonId)
  $prog | ConvertTo-Json -Depth 40 | Set-Content -Path $progPath -Encoding UTF8

  # award XP
  $xp = 10
  foreach ($m in $track.modules) {
    foreach ($l in $m.lessons) {
      if ($l.id -eq $LessonId -and $l.PSObject.Properties.Name -contains "xp") { $xp = [int]$l.xp }
    }
  }
  try { Add-OsXP -Amount $xp -Reason ("Lesson "+$TrackId+"/"+$LessonId) | Out-Null } catch {}

  $total2 = 0; foreach ($m in $track.modules) { $total2 += @($m.lessons).Count }
  $done2  = @($prog.$TrackId.completedLessons).Count
  $progress2 = if ($total2 -gt 0) { [Math]::Round(($done2*100.0)/$total2) } else { 0 }

  return @{ status="ok"; trackId=$TrackId; lessonId=$LessonId; awarded=$xp; totals=@{lessons=$total2;completed=$done2}; progress=$progress2 }
}

# ---- HTTP listener ----
$Port = 7780
$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
if (-not $env:OSB_NO_AUTO_LAUNCH) { # Start-Process "http://localhost:$Port/" }
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath

      switch -Regex ($path) {
        '^/$' {
          $idx = Join-Path $Www 'index.html'
          if (Test-Path $idx) { Write-File $res $idx 'text/html; charset=utf-8' } else { Write-Json $res @{ error="Missing index.html" } 404 }
          continue
        }
        '^/client\.js$' {
          $p = Join-Path $Www 'client.js'
          if (Test-Path $p) { Write-File $res $p 'application/javascript; charset=utf-8' } else { Write-Json $res @{ error="Missing client.js" } 404 }
          continue
        }
        '^/mirror\.json$' {
          $p = Join-Path $Www 'mirror.json'
          if (Test-Path $p) { Write-File $res $p 'application/json; charset=utf-8' } else { Write-Json $res @{ error="Not found: /mirror.json" } 404 }
          continue
        }
        '^/diag$' {
          $visible = Get-Command Add-OsXP,Get-OsXP,Initialize-OsStore,Get-OsStore,Save-OsStore -ErrorAction SilentlyContinue | Select-Object Name,ModuleName
          $exists  = @{
            store      = (Test-Path (Join-Path $DataDir 'store.plasma'))
            curriculum = (Test-Path (Join-Path $DataDir 'curriculum.json'))
            progress   = (Test-Path (Join-Path $DataDir 'progress.lessons.json'))
          }
          Write-Json $res @{ mode="module"; exists=$exists; visible=$visible; modulesPath=$Modules }
          continue
        }
        '^/xp\.json$' {
          $days = 30
          if ($req.Url.Query -match 'days=(\d+)') { $days = [int]$Matches[1] }
          Write-Json $res (Summarize-XP -Days $days)
          continue
        }
        '^/api/xp/add$' {
          $b = Read-Body $req
          $delta  = [int]($b.delta)
          $reason = [string]($b.reason)
          $delta  = if ($delta) { $delta } else { 0 }
          $entry  = Add-OsXP -Amount $delta -Reason $reason
          $o = Get-OsXP
          Write-Json $res @{ ok=$true; xp=$o.XP; rank=$o.Rank; progressPct=$o.ProgressPct }
          continue
        }
        '^/api/lessons/summary$' {
          Write-Json $res (Get-LessonsSummary)
          continue
        }
        '^/api/lessons/track/([^/]+)$' {
          $tid = $Matches[1]
          $t = Get-LessonsTrack -TrackId $tid
          if ($t) { Write-Json $res $t } else { Write-Json $res @{ error="track-not-found" } 404 }
          continue
        }
        '^/api/lessons/complete$' {
          $b = Read-Body $req
          $tid = [string]$b.trackId
          $lid = [string]$b.lessonId
          if ([string]::IsNullOrWhiteSpace($tid) -and $req.Url.Query -match 'trackId=([^&]+)') { $tid = [Uri]::UnescapeDataString($Matches[1]) }
          if ([string]::IsNullOrWhiteSpace($lid) -and $req.Url.Query -match 'lessonId=([^&]+)') { $lid = [Uri]::UnescapeDataString($Matches[1]) }
          if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) { Write-Json $res @{ error="missing-track-or-lesson" } 400; continue }
          $result = Complete-Lesson -TrackId $tid -LessonId $lid
          if ($result.error) { Write-Json $res $result 400 } else { Write-Json $res $result }
          continue
        }
        default {
          # Try to serve any other file from /www
          $p = $path.TrimStart('/')
          $f = Join-Path $Www $p
          if (Test-Path $f) {
            $ct = 'text/plain'
            switch -Regex ($f) {
              '\.html?$' { $ct='text/html; charset=utf-8' }
              '\.js$'    { $ct='application/javascript; charset=utf-8' }
              '\.css$'   { $ct='text/css; charset=utf-8' }
              '\.json$'  { $ct='application/json; charset=utf-8' }
              '\.(png|jpg|jpeg|gif|webp|svg)$' { $ct='application/octet-stream' }
            }
            Write-File $res $f $ct
          } else {
            Write-Json $res @{ error=("Not found: " + $path) } 404
          }
          continue
        }
      }
    } catch {
      try { Write-Json $res @{ error="server-fault" } 500 } catch {}
    }
  }
} finally {
  try { $listener.Stop() } catch {}
}

