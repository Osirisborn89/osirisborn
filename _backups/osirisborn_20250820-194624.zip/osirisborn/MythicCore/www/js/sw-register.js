(function(){
  try{
    var url = new URL(location.href);
    var offQ = (url.searchParams.get('sw')||'').toLowerCase() === 'off';
    var host = location.hostname || '';
    var isLocal = (host === '127.0.0.1' || host === 'localhost');

    if (offQ || isLocal) {
      console.log('[SW] dev mode: service worker disabled');
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.getRegistrations().then(function(rs){
          rs.forEach(function(r){ r.unregister(); });
        });
      }
      return;
    }

    if (!('serviceWorker' in navigator)) return;
    navigator.serviceWorker.register('./sw.js')
      .then(function(r){ console.log('[SW] registered ok; scope=', r.scope); })
      .catch(function(e){ console.warn('[SW] register failed', e); });
  }catch(e){ console.warn('[SW] error', e); }
})();
