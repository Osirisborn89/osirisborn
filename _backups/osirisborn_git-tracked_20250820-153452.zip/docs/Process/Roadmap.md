# Roadmap (Live)

**Phase 0 — Repo & Governance** ✅  
**Phase 1 — Mythic Core (server + UI + XP + missions)** ✅ (baseline running)  
**Phase 2 — Handover Pack & Docs** (THIS PR)  
**Phase 3 — Curriculum Engine v1**  
**Phase 4 — Gamification v1**  
**Phase 5 — Dashboard Modes & Persona v1**  
**Phase 6 — Toolkit Vault v1**  
**Phase 7 — Downtime Lounge v1**  
**Phase 8 — Flashcards & SRS v1**  
**Phase 9 — Cyber Range v0 → v1**  
**Phase 10 — Anubis v0 → v1 (offline core, optional online)**  
**Phase 11 — Privacy & Security Core**  
**Phase 12 — Packaging & Windows Beta**  
**Phase 13 — Expansions (Darknet, Quantum, Mission Generator, Spectral Trials)**

Milestones + acceptance criteria will be tracked as checklists per phase.
