See MASTER_BLUEPRINT.md → Persona Switching & Identity System. Quick-switch, OPSEC profiles, Anubis tone swap.
