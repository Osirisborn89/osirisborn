See MASTER_BLUEPRINT.md → XP System & Ranks. Initiate → Osirisborn. Achievements, streaks, trophies, celebration mode.
