
- ✅ LESS-002 merged on 2025-08-16: curriculum + read APIs live
