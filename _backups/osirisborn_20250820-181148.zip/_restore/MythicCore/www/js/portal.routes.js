(function(){
  const routes = {
    "#/home":  "view-home",
    "#/learn": "view-learn",
    "#/learn/coding": "view-learn-coding",
    "#/learn/coding/languages": "view-learn-coding-langs",
    "#/learn/coding/languages/all": "view-learn-coding-langs-all",
    "#/lounge":"view-lounge",
  };

  function setActiveLink(hash){
    const h = hash || "#/home";
    document.querySelectorAll("header a[data-nav]").forEach(a=>{
      if (a.getAttribute("href") === h) a.classList.add("active");
      else a.classList.remove("active");
    });
  }

  function show(hash){
    const id = routes[hash] || "view-home";
    document.querySelectorAll(".view").forEach(v=>v.classList.remove("show"));
    const el = document.getElementById(id);
    if (el) el.classList.add("show");
    setActiveLink(hash);
  }

  // First run + changes
  window.addEventListener("hashchange", ()=> show(location.hash || "#/home"));
  document.addEventListener("DOMContentLoaded", ()=>{
    const h = location.hash || "#/home";
    if (h === "#/" || h === "#") location.hash = "#/home";
    show(location.hash || "#/home");
  });

  // Safety: dev mode SW off
  try{
    const url = new URL(location.href);
    const swOff = url.searchParams.get("sw") === "off";
    const isLocal = (location.hostname==="127.0.0.1"||location.hostname==="localhost");
    if (swOff || isLocal) {
      if ("serviceWorker" in navigator) {
        navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister()));
      }
    }
  }catch(e){}
})();
