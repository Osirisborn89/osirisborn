;(() => {
  console.log('LESS-020 router iife');
  const byId = (id) => document.getElementById(id);
  const app = () => byId('app');

  const View = {
    home() {
      return 
<section id="view-home" class="view">
  <div class="hero">
    <h1>Black Pyramid</h1>
    <p>Mythic OS for Learning, Hacking, and Mastery.</p>
    <div class="quick-actions">
      <a href="#/learn">Enter Learning</a>
      <a href="#/lounge">Downtime Lounge</a>
      <a href="#/project">Project Station</a>
      <a href="#/cyber">Cybertools</a>
      <a href="#/help">Help / FAQ</a>
    </div>
  </div>
  <div class="widgets">
    <div class="widget">
      <h3>XP / Rank</h3>
      <div class="badge">Rank: Initiate</div>
      <div class="divider"></div>
      <div>Progress: 0% → Next Rank</div>
      <div class="divider"></div>
      <div>Daily mission: <i>Placeholder</i></div>
    </div>
    <div class="widget">
      <h3>Today</h3>
      <div>Recent activity: <i>Not yet recorded</i></div>
      <div class="divider"></div>
      <div>Anubis tip: <i>Coming soon</i></div>
    </div>
  </div>
  <div class="tile-grid">
    <a class="tile" href="#/learn"><div><h4>Learning Hub</h4><p>Python, JS, C++, Cybersecurity, CTFs…</p></div><div class="badge">Core</div></a>
    <a class="tile" href="#/lounge"><div><h4>Downtime Lounge</h4><p>Playlists, games, timers</p></div><div class="badge">Core</div></a>
    <a class="tile" href="#/project"><div><h4>Project Station</h4><p>Capstones, repos</p></div><div class="badge">Core</div></a>
    <a class="tile" href="#/cyber"><div><h4>Cybertools Vault</h4><p>Snippets, BYOT</p></div><div class="badge">Core</div></a>
    <a class="tile" href="#/help"><div><h4>Help / FAQ</h4><p>Guides, troubleshooting</p></div><div class="badge">Core</div></a>
    <a class="tile" href="#/ai"><div><h4>Anubis AI</h4><p>Mentor • Hype • Zen</p></div><div class="badge">Soon</div></a>
    <a class="tile" href="#/identity"><div><h4>Identity Hub</h4><p>Personas, VPN/Firewall</p></div><div class="badge">Soon</div></a>
    <a class="tile" href="#/xp"><div><h4>XP & Achievements</h4><p>Ranks, badges</p></div><div class="badge">Soon</div></a>
    <a class="tile" href="#/career"><div><h4>Career Tools</h4><p>Resume, portfolio</p></div><div class="badge">Soon</div></a>
    <a class="tile" href="#/lore"><div><h4>Lore & Expansions</h4><p>Memory Palace, Darknet, Quantum</p></div><div class="badge">Soon</div></a>
  </div>
  <div class="footer">Build: <span id="bp-build">dev</span></div>
</section>;
    },

    learn(){ return <section id="view-learn"><h2>Learning Hub</h2><p>Placeholder</p></section>; },
    lounge(){ return <section id="view-lounge"><h2>Downtime Lounge</h2><p>Placeholder</p></section>; },

    project(){ return <section id="view-project"><h2>Project Station</h2><p>Placeholder</p></section>; },
    cyber(){ return <section id="view-cyber"><h2>Cybertools</h2><p>Placeholder</p></section>; },
    help(){ return <section id="view-help"><h2>Help / FAQ</h2><p>Placeholder</p></section>; },

    ai(){ return <section id="view-ai"><h2>Anubis AI</h2><p>Coming soon</p></section>; },
    identity(){ return <section id="view-identity"><h2>Identity Hub</h2><p>Coming soon</p></section>; },
    xp(){ return <section id="view-xp"><h2>XP / Achievements</h2><p>Coming soon</p></section>; },
    career(){ return <section id="view-career"><h2>Career Tools</h2><p>Coming soon</p></section>; },
    lore(){ return <section id="view-lore"><h2>Lore & Expansions</h2><p>Coming soon</p></section>; },
  };

  const titleOf = (key) => ({
    home:"Home", learn:"Learning", lounge:"Downtime Lounge",
    project:"Project Station", cyber:"Cybertools", help:"Help / FAQ",
    ai:"Anubis AI", identity:"Identity Hub", xp:"XP / Achievements",
    career:"Career Tools", lore:"Lore & Expansions"
  }[key] || "Black Pyramid");

  function render() {
    const hash = (location.hash || "#/home");
    const key = hash.replace(/^#\//,"") || "home";
    const el = app();
    if (!el) { console.warn('LESS-024 #app not found'); return; }
    const view = View[key] ? View[key]() : View.home();
    el.innerHTML = view;
    document.title = Black Pyramid — ;
    console.log('LESS-025 render', {key});
  }

  window.addEventListener('hashchange', () => { console.log('LESS-018 hashchange'); try { render(); } catch(e){ console.error('render err hashchange', e); } });
  window.addEventListener('DOMContentLoaded', () => { console.log('LESS-017 router DOMContentLoaded'); try { render(); } catch(e){ console.error('render err DOMContentLoaded', e); } });
  setTimeout(() => { try { render(); console.log('LESS-019 router re-render'); } catch(e){ console.error('render err rerender', e); } }, 100);
})();
