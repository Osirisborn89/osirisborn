﻿#requires -Version 7.0
# ==== BEGIN BP XP FALLBACK (Get-OsXP/Add-OsXP) ====
if (-not (Get-Command Get-OsXP -ErrorAction SilentlyContinue)) {
  function Get-OsXP {
    param([int]$Days)
    $s = Get-OsStore -Ensure
    if (-not $s.xp)        { $s | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $s.xp.events) { $s.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $s.xp
  }
}

if (-not (Get-Command Add-OsXP -ErrorAction SilentlyContinue)) {
  function Add-OsXP {
    param(
      [Parameter(Mandatory=$true)][int]$Delta,
      [Parameter()][string]$Reason = "",
      [Parameter()][datetime]$At = (Get-Date)
    )
    $s = Get-OsStore -Ensure
    if (-not $s.xp)        { $s | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $s.xp.events) { $s.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    $evt = [PSCustomObject]@{ ts = $At.ToString("o"); delta = $Delta; reason = $Reason }
    $s.xp.events = @($s.xp.events + $evt)
    Save-OsStore -Store $s | Out-Null
    return $evt
  }
}
# ==== END BP XP FALLBACK ====

# ==== BEGIN BP STORE FALLBACK (Initialize/Get/Save-OsStore) ====
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root = $root; dataDir = $dataDir; storePath = $storePath }
}

if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      $p = _bpStorePaths
      if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
      if (-not (Test-Path $p.storePath)) {
        '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}

if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $p = _bpStorePaths
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $p.storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $p.storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json
    } catch {
      $obj = ConvertFrom-Json '{"xp":{"events":[]}}'
      $obj | ConvertTo-Json -Depth 50 | Set-Content -Path $p.storePath -Encoding UTF8
    }
    if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $obj
  }
}

if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $p = _bpStorePaths
    Initialize-OsStore | Out-Null
    try {
      $json = $Store | ConvertTo-Json -Depth 50
      $json | Set-Content -Path $p.storePath -Encoding UTF8
      return $true
    } catch { return $false }
  }
}
# ==== END BP STORE FALLBACK ====

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'
$Mirror  = Join-Path $Www 'mirror.json'

. (Join-Path $Modules 'Osirisborn.Store.psm1')
. (Join-Path $Modules 'Osirisborn.XP.psm1')
. (Join-Path $Modules 'Osirisborn.Missions.psm1')

function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $res.StatusCode = $status
    $json  = ($obj | ConvertTo-Json -Depth 6)
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 6 } catch { return @{} }
}
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  return @{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  }
}

# Use 7780 to avoid any 7777 conflicts
$Port = 7780

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
# OSB: disabled opener -> Start-Process "http://localhost:$Port/"
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath
# ==== BEGIN XP SAFE GUARD (LESS-003) ====
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 50 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root=$root; dataDir=$dataDir; storePath=$storePath }
}
function _bpEnsureStore {
  $p = _bpStorePaths
  if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
  if (-not (Test-Path $p.storePath)) { '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8 }
  return $p
}
function _bpReadStore {
  $p = _bpEnsureStore
  try { $raw = Get-Content $p.storePath -Raw -ErrorAction Stop } catch { $raw = '{"xp":{"events":[]}}' }
  try { $obj = $raw | ConvertFrom-Json } catch { $obj = ConvertFrom-Json '{"xp":{"events":[]}}' }
  if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
  if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
  [PSCustomObject]@{ path = $p.storePath; store = $obj }
}
function _bpSaveStore($obj){
  $p = _bpStorePaths
  ($obj | ConvertTo-Json -Depth 50) | Set-Content -Path $p.storePath -Encoding UTF8
}

#requires -Version 7.0

# ==== BEGIN BP STORE FALLBACK (Initialize/Get/Save-OsStore) ====
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root = $root; dataDir = $dataDir; storePath = $storePath }
}

if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      $p = _bpStorePaths
      if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
      if (-not (Test-Path $p.storePath)) {
        '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}

if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $p = _bpStorePaths
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $p.storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $p.storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json
    } catch {
      $obj = ConvertFrom-Json '{"xp":{"events":[]}}'
      $obj | ConvertTo-Json -Depth 50 | Set-Content -Path $p.storePath -Encoding UTF8
    }
    if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $obj
  }
}

if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $p = _bpStorePaths
    Initialize-OsStore | Out-Null
    try {
      $json = $Store | ConvertTo-Json -Depth 50
      $json | Set-Content -Path $p.storePath -Encoding UTF8
      return $true
    } catch { return $false }
  }
}
# ==== END BP STORE FALLBACK ====

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'
$Mirror  = Join-Path $Www 'mirror.json'

. (Join-Path $Modules 'Osirisborn.Store.psm1')
. (Join-Path $Modules 'Osirisborn.XP.psm1')
. (Join-Path $Modules 'Osirisborn.Missions.psm1')

function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $res.StatusCode = $status
    $json  = ($obj | ConvertTo-Json -Depth 6)
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 6 } catch { return @{} }
}
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  return @{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  }
}

# Use 7780 to avoid any 7777 conflicts
$Port = 7780

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
# OSB: disabled opener -> Start-Process "http://localhost:$Port/"
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath
# ==== BEGIN LESSONS API GUARD (LESS-003) ====
# Defensive helpers
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 12 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpDataDir {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  [IO.Path]::GetFullPath((Join-Path $root "..\data"))
}
function _bpReadBody {
  $req = _bpGetReq
  if (-not $req) { return $null }
  try {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $s  = $sr.ReadToEnd(); $sr.Close(); return $s
  } catch { return $null }
}

# Short-circuit based on path (and method for POST)
$__p = $path
$__m = ( _bpGetReq )?.HttpMethod

if ($__p -eq "/api/lessons/summary") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    $tracks = @()

    if (Test-Path $currPath) {
      $curr = Get-Content $currPath -Raw | ConvertFrom-Json
      $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }

      foreach ($t in $curr.tracks) {
        $lessonsCount = 0
        foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
        $completed = 0
        if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
          $completed = @($prog.$($t.id).completedLessons).Count
        }
        $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
        $tracks += [PSCustomObject]@{
          id        = $t.id
          title     = $t.title
          lessons   = $lessonsCount
          completed = $completed
          progress  = $progress
        }
      }
    }

    _bpWriteJson ([PSCustomObject]@{ totalTracks = @($tracks).Count; tracks = $tracks })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-summary-failed" } 500
    continue
  }
}
elseif ($__p -like "/api/lessons/track/*") {
  try {
    $tid = $__p.Substring("/api/lessons/track/".Length)
    if ([string]::IsNullOrWhiteSpace($tid)) { _bpWriteJson @{ error="missing-track-id" } 400; continue }

    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    $completedSet = @{}
    if ($prog -and ($prog.PSObject.Properties.Name -contains $tid)) {
      foreach ($lid in $prog.$tid.completedLessons) { $completedSet[$lid] = $true }
    }

    $total = 0; $done = 0
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        $total++
        if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true -Force }
        else                                   {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
      }
    }
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }

    _bpWriteJson ([PSCustomObject]@{
      id       = $track.id
      title    = $track.title
      progress = $progress
      modules  = $track.modules
      totals   = @{ lessons = $total; completed = $done }
    })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-track-failed" } 500
    continue
  }
}
elseif ($__m -eq "POST" -and $__p -eq "/api/lessons/complete") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $body = _bpReadBody
    if (-not $body) { _bpWriteJson @{ error="missing-body" } 400; continue }
    try { $obj = $body | ConvertFrom-Json } catch { _bpWriteJson @{ error="bad-json" } 400; continue }

    $tid = $obj.trackId; $lid = $obj.lessonId
    if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) {
      _bpWriteJson @{ error="missing-params" } 400; continue
    }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    # Locate lesson and XP
    $foundLesson = $null
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        if ($l.id -eq $lid) { $foundLesson = $l; break }
      }
      if ($foundLesson) { break }
    }
    if (-not $foundLesson) { _bpWriteJson @{ error="lesson-not-found" } 404; continue }

    $xp = $foundLesson.xp
    if (-not $xp) { $xp = $track.xpPerLesson }
    if (-not $xp) { $xp = 10 }

    # Read or init progress
    if (Test-Path $progPath) { $prog = Get-Content $progPath -Raw | ConvertFrom-Json } else { $prog = @{} | ConvertTo-Json | ConvertFrom-Json }
    if (-not ($prog.PSObject.Properties.Name -contains $tid)) {
      $prog | Add-Member -NotePropertyName $tid -NotePropertyValue ( [PSCustomObject]@{ completedLessons = @() } ) -Force
    }

    $list = @($prog.$tid.completedLessons)
    $already = $false
    foreach ($x in $list) { if ($x -eq $lid) { $already = $true; break } }

    if ($already) {
      # compute current totals/progress
      $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
      $completed = @($prog.$tid.completedLessons).Count
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      _bpWriteJson @{ status="exists"; awarded=0; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
      continue
    }

    # Append, save
    $newList = @($prog.$tid.completedLessons + $lid)
    $prog.$tid.completedLessons = $newList
    # Persist to file
    $jsonOut = $prog | ConvertTo-Json -Depth 12
    $jsonOut | Set-Content -Path $progPath -Encoding UTF8

    # compute new totals/progress
    $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
    $completed = @($prog.$tid.completedLessons).Count
    $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }

    _bpWriteJson @{ status="ok"; awarded=$xp; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-complete-failed" } 500
    continue
  }
}
# ==== END LESSONS API GUARD (LESS-003) ====
      $method = $req.HttpMethod.ToUpperInvariant()

      # Static
# ---- XP: add (module-first, with safe fallback)
if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
  $b = Read-Body $req
  $delta  = [int]$b.delta
  $reason = [string]$b.reason
  if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
  if ([string]::IsNullOrWhiteSpace($reason)) { $reason = 'Manual XP' }

  $usedModules = $false
  try {
    if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
      Add-OsXP -Amount $delta -Reason $reason | Out-Null
      $usedModules = $true
    }
  } catch {}

  if (-not $usedModules) {
    # ---- minimal self-contained fallback (no Initialize-OsStore dependency)
    if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
    $storePath = Join-Path $DataDir 'store.plasma'
    if (!(Test-Path $storePath)) {
      $default = [pscustomobject]@{
        user = [pscustomobject]@{ xp=0; rank='Initiate'; alias='Osirisborn'; progressPct=0 }
        missions = [pscustomobject]@{ catalog=@{}; completed=@() }
        meta = [pscustomobject]@{ xpLog=@() }
        settings = [pscustomobject]@{ dailyGoal=300; notify=$true }
      }
      Set-Content -Path $storePath -Value ($default | ConvertTo-Json -Depth 6) -Encoding UTF8
    }
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $s.user.xp = [int]($s.user.xp) + $delta

    # rank & progress (same thresholds as CLI)
    $threshold = @{
      'Initiate'=0; 'Ghost'=200; 'Signal Diver'=600; 'Network Phantom'=1200; 'Redline Operative'=2000;
      'Shadow Architect'=3000; 'Spectral Engineer'=4500; 'Elite'=6500; 'Voidbreaker'=9000; 'God Tier: Osirisborn'=12000
    }
    $ranks = @('Initiate','Ghost','Signal Diver','Network Phantom','Redline Operative','Shadow Architect','Spectral Engineer','Elite','Voidbreaker','God Tier: Osirisborn')
    foreach($r in $ranks){ if ($s.user.xp -ge $threshold[$r]) { $s.user.rank=$r } }
    $curr = $threshold[$s.user.rank]
    $next = $threshold[$ranks[[Math]::Min($ranks.IndexOf($s.user.rank)+1, $ranks.Count-1)]]
    $span = [Math]::Max(1, $next-$curr)
    $s.user.progressPct = [int][Math]::Clamp(100*($s.user.xp-$curr)/$span,0,100)

    # log entry
    if (-not $s.meta) { $s | Add-Member meta ([pscustomobject]@{}) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member xpLog @() -Force }
    $s.meta.xpLog = @($s.meta.xpLog + [pscustomobject]@{
      at=(Get-Date).ToString('o'); delta=$delta; reason=$reason; total=[int]$s.user.xp; rank=$s.user.rank
    })

    Set-Content $storePath ($s | ConvertTo-Json -Depth 6) -Encoding UTF8
  }

  # respond with current xp/rank
  $xp = $null
  if (Get-Command Get-OsXP -ErrorAction SilentlyContinue) { $xp = Get-OsXP }
  if (-not $xp) {
    $storePath = Join-Path $DataDir 'store.plasma'
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $xp = [pscustomobject]@{ Rank=$s.user.rank; XP=[int]$s.user.xp; ProgressPct=[int]($s.user.progressPct) }
  }
  Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=[int]($xp.ProgressPct) }; continue
}
      
if     ($path -eq '/' -or $path -match '^/index\.html$') { Write-File $res (Join-Path $Www 'index.html') 'text/html; charset=utf-8'; continue }
      elseif ($path -match '^/client\.js$')                    { Write-File $res (Join-Path $Www 'client.js') 'application/javascript; charset=utf-8'; continue }
      elseif ($path -match '^/mirror\.json$' -and (Test-Path $Mirror)) { Write-File $res $Mirror 'application/json; charset=utf-8'; continue }

      # DIAG
      if ($path -eq '/diag') {
        $exists = @{
          store    = Test-Path (Join-Path $Modules 'Osirisborn.Store.psm1')
          xp       = Test-Path (Join-Path $Modules 'Osirisborn.XP.psm1')
          missions = Test-Path (Join-Path $Modules 'Osirisborn.Missions.psm1')
        }
        $visible = Get-Command Add-OsMission,Get-OsMissions,Complete-OsMission,Add-OsXP,Get-OsXP -ErrorAction SilentlyContinue |
                   Select-Object Name,ModuleName
        Write-Json $res @{ mode='module'; modulesPath=$Modules; exists=$exists; visible=$visible }; continue
      }

      # XP
      if ($path -eq '/xp.json') {
        $days = 30; try { if ($req.QueryString['days']) { $days = [int]$req.QueryString['days'] } } catch {}
        Write-Json $res (Summarize-XP -Days $days); continue
      }
      if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $delta=[int]$b.delta; $reason="$($b.reason)"
        if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
        if (-not $reason) { $reason = 'Manual XP' }
        if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
          Add-OsXP -Amount $delta -Reason $reason | Out-Null
        } else {
          Initialize-OsStore
          $s = Get-OsStore
          $s.user.xp = [int]$s.user.xp + $delta
          Save-OsStore $s
        }
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # Missions
      if ($path -eq '/api/missions' -and $method -eq 'GET') {
        Initialize-OsStore
        $items = Get-OsMissions | ForEach-Object {
          [pscustomobject]@{ id="$($_.Id)"; title="$($_.Title)"; xp=[int]$_.XP; status="$($_.Status)" }
        }
        Write-Json $res @{ items = @($items) }; continue
      }
      if ($path -eq '/api/mission/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"; $title="$($b.title)"; $xp=[int]$b.xp
        if (-not $id)    { Write-Json $res @{ error="Missing id" } 400; continue }
        if (-not $title) { $title='New Mission' }
        Add-OsMission -Id $id -XP $xp -Title $title | Out-Null
        Write-Json $res @{ ok=$true; id=$id }; continue
      }
      if ($path -eq '/api/mission/complete' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"
        if (-not $id) { Write-Json $res @{ error='Missing id' } 400; continue }
        $null = Complete-OsMission -Id $id
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; id=$id; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # 404
      Write-Json $res @{ error = "Not found: $path" } 404
    } catch {
      try { Write-Json $ctx.Response @{ error = $_.Exception.Message } } catch {}
    }
  }
} finally { try { $listener.Stop(); $listener.Close() } catch {} }

_req = _bpGetReq
#requires -Version 7.0

# ==== BEGIN BP STORE FALLBACK (Initialize/Get/Save-OsStore) ====
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root = $root; dataDir = $dataDir; storePath = $storePath }
}

if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      $p = _bpStorePaths
      if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
      if (-not (Test-Path $p.storePath)) {
        '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}

if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $p = _bpStorePaths
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $p.storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $p.storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json
    } catch {
      $obj = ConvertFrom-Json '{"xp":{"events":[]}}'
      $obj | ConvertTo-Json -Depth 50 | Set-Content -Path $p.storePath -Encoding UTF8
    }
    if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $obj
  }
}

if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $p = _bpStorePaths
    Initialize-OsStore | Out-Null
    try {
      $json = $Store | ConvertTo-Json -Depth 50
      $json | Set-Content -Path $p.storePath -Encoding UTF8
      return $true
    } catch { return $false }
  }
}
# ==== END BP STORE FALLBACK ====

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'
$Mirror  = Join-Path $Www 'mirror.json'

. (Join-Path $Modules 'Osirisborn.Store.psm1')
. (Join-Path $Modules 'Osirisborn.XP.psm1')
. (Join-Path $Modules 'Osirisborn.Missions.psm1')

function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $res.StatusCode = $status
    $json  = ($obj | ConvertTo-Json -Depth 6)
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 6 } catch { return @{} }
}
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  return @{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  }
}

# Use 7780 to avoid any 7777 conflicts
$Port = 7780

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
# OSB: disabled opener -> Start-Process "http://localhost:$Port/"
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath
# ==== BEGIN LESSONS API GUARD (LESS-003) ====
# Defensive helpers
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 12 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpDataDir {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  [IO.Path]::GetFullPath((Join-Path $root "..\data"))
}
function _bpReadBody {
  $req = _bpGetReq
  if (-not $req) { return $null }
  try {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $s  = $sr.ReadToEnd(); $sr.Close(); return $s
  } catch { return $null }
}

# Short-circuit based on path (and method for POST)
$__p = $path
$__m = ( _bpGetReq )?.HttpMethod

if ($__p -eq "/api/lessons/summary") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    $tracks = @()

    if (Test-Path $currPath) {
      $curr = Get-Content $currPath -Raw | ConvertFrom-Json
      $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }

      foreach ($t in $curr.tracks) {
        $lessonsCount = 0
        foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
        $completed = 0
        if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
          $completed = @($prog.$($t.id).completedLessons).Count
        }
        $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
        $tracks += [PSCustomObject]@{
          id        = $t.id
          title     = $t.title
          lessons   = $lessonsCount
          completed = $completed
          progress  = $progress
        }
      }
    }

    _bpWriteJson ([PSCustomObject]@{ totalTracks = @($tracks).Count; tracks = $tracks })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-summary-failed" } 500
    continue
  }
}
elseif ($__p -like "/api/lessons/track/*") {
  try {
    $tid = $__p.Substring("/api/lessons/track/".Length)
    if ([string]::IsNullOrWhiteSpace($tid)) { _bpWriteJson @{ error="missing-track-id" } 400; continue }

    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    $completedSet = @{}
    if ($prog -and ($prog.PSObject.Properties.Name -contains $tid)) {
      foreach ($lid in $prog.$tid.completedLessons) { $completedSet[$lid] = $true }
    }

    $total = 0; $done = 0
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        $total++
        if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true -Force }
        else                                   {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
      }
    }
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }

    _bpWriteJson ([PSCustomObject]@{
      id       = $track.id
      title    = $track.title
      progress = $progress
      modules  = $track.modules
      totals   = @{ lessons = $total; completed = $done }
    })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-track-failed" } 500
    continue
  }
}
elseif ($__m -eq "POST" -and $__p -eq "/api/lessons/complete") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $body = _bpReadBody
    if (-not $body) { _bpWriteJson @{ error="missing-body" } 400; continue }
    try { $obj = $body | ConvertFrom-Json } catch { _bpWriteJson @{ error="bad-json" } 400; continue }

    $tid = $obj.trackId; $lid = $obj.lessonId
    if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) {
      _bpWriteJson @{ error="missing-params" } 400; continue
    }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    # Locate lesson and XP
    $foundLesson = $null
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        if ($l.id -eq $lid) { $foundLesson = $l; break }
      }
      if ($foundLesson) { break }
    }
    if (-not $foundLesson) { _bpWriteJson @{ error="lesson-not-found" } 404; continue }

    $xp = $foundLesson.xp
    if (-not $xp) { $xp = $track.xpPerLesson }
    if (-not $xp) { $xp = 10 }

    # Read or init progress
    if (Test-Path $progPath) { $prog = Get-Content $progPath -Raw | ConvertFrom-Json } else { $prog = @{} | ConvertTo-Json | ConvertFrom-Json }
    if (-not ($prog.PSObject.Properties.Name -contains $tid)) {
      $prog | Add-Member -NotePropertyName $tid -NotePropertyValue ( [PSCustomObject]@{ completedLessons = @() } ) -Force
    }

    $list = @($prog.$tid.completedLessons)
    $already = $false
    foreach ($x in $list) { if ($x -eq $lid) { $already = $true; break } }

    if ($already) {
      # compute current totals/progress
      $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
      $completed = @($prog.$tid.completedLessons).Count
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      _bpWriteJson @{ status="exists"; awarded=0; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
      continue
    }

    # Append, save
    $newList = @($prog.$tid.completedLessons + $lid)
    $prog.$tid.completedLessons = $newList
    # Persist to file
    $jsonOut = $prog | ConvertTo-Json -Depth 12
    $jsonOut | Set-Content -Path $progPath -Encoding UTF8

    # compute new totals/progress
    $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
    $completed = @($prog.$tid.completedLessons).Count
    $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }

    _bpWriteJson @{ status="ok"; awarded=$xp; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-complete-failed" } 500
    continue
  }
}
# ==== END LESSONS API GUARD (LESS-003) ====
      $method = $req.HttpMethod.ToUpperInvariant()

      # Static
# ---- XP: add (module-first, with safe fallback)
if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
  $b = Read-Body $req
  $delta  = [int]$b.delta
  $reason = [string]$b.reason
  if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
  if ([string]::IsNullOrWhiteSpace($reason)) { $reason = 'Manual XP' }

  $usedModules = $false
  try {
    if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
      Add-OsXP -Amount $delta -Reason $reason | Out-Null
      $usedModules = $true
    }
  } catch {}

  if (-not $usedModules) {
    # ---- minimal self-contained fallback (no Initialize-OsStore dependency)
    if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
    $storePath = Join-Path $DataDir 'store.plasma'
    if (!(Test-Path $storePath)) {
      $default = [pscustomobject]@{
        user = [pscustomobject]@{ xp=0; rank='Initiate'; alias='Osirisborn'; progressPct=0 }
        missions = [pscustomobject]@{ catalog=@{}; completed=@() }
        meta = [pscustomobject]@{ xpLog=@() }
        settings = [pscustomobject]@{ dailyGoal=300; notify=$true }
      }
      Set-Content -Path $storePath -Value ($default | ConvertTo-Json -Depth 6) -Encoding UTF8
    }
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $s.user.xp = [int]($s.user.xp) + $delta

    # rank & progress (same thresholds as CLI)
    $threshold = @{
      'Initiate'=0; 'Ghost'=200; 'Signal Diver'=600; 'Network Phantom'=1200; 'Redline Operative'=2000;
      'Shadow Architect'=3000; 'Spectral Engineer'=4500; 'Elite'=6500; 'Voidbreaker'=9000; 'God Tier: Osirisborn'=12000
    }
    $ranks = @('Initiate','Ghost','Signal Diver','Network Phantom','Redline Operative','Shadow Architect','Spectral Engineer','Elite','Voidbreaker','God Tier: Osirisborn')
    foreach($r in $ranks){ if ($s.user.xp -ge $threshold[$r]) { $s.user.rank=$r } }
    $curr = $threshold[$s.user.rank]
    $next = $threshold[$ranks[[Math]::Min($ranks.IndexOf($s.user.rank)+1, $ranks.Count-1)]]
    $span = [Math]::Max(1, $next-$curr)
    $s.user.progressPct = [int][Math]::Clamp(100*($s.user.xp-$curr)/$span,0,100)

    # log entry
    if (-not $s.meta) { $s | Add-Member meta ([pscustomobject]@{}) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member xpLog @() -Force }
    $s.meta.xpLog = @($s.meta.xpLog + [pscustomobject]@{
      at=(Get-Date).ToString('o'); delta=$delta; reason=$reason; total=[int]$s.user.xp; rank=$s.user.rank
    })

    Set-Content $storePath ($s | ConvertTo-Json -Depth 6) -Encoding UTF8
  }

  # respond with current xp/rank
  $xp = $null
  if (Get-Command Get-OsXP -ErrorAction SilentlyContinue) { $xp = Get-OsXP }
  if (-not $xp) {
    $storePath = Join-Path $DataDir 'store.plasma'
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $xp = [pscustomobject]@{ Rank=$s.user.rank; XP=[int]$s.user.xp; ProgressPct=[int]($s.user.progressPct) }
  }
  Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=[int]($xp.ProgressPct) }; continue
}
      
if     ($path -eq '/' -or $path -match '^/index\.html$') { Write-File $res (Join-Path $Www 'index.html') 'text/html; charset=utf-8'; continue }
      elseif ($path -match '^/client\.js$')                    { Write-File $res (Join-Path $Www 'client.js') 'application/javascript; charset=utf-8'; continue }
      elseif ($path -match '^/mirror\.json$' -and (Test-Path $Mirror)) { Write-File $res $Mirror 'application/json; charset=utf-8'; continue }

      # DIAG
      if ($path -eq '/diag') {
        $exists = @{
          store    = Test-Path (Join-Path $Modules 'Osirisborn.Store.psm1')
          xp       = Test-Path (Join-Path $Modules 'Osirisborn.XP.psm1')
          missions = Test-Path (Join-Path $Modules 'Osirisborn.Missions.psm1')
        }
        $visible = Get-Command Add-OsMission,Get-OsMissions,Complete-OsMission,Add-OsXP,Get-OsXP -ErrorAction SilentlyContinue |
                   Select-Object Name,ModuleName
        Write-Json $res @{ mode='module'; modulesPath=$Modules; exists=$exists; visible=$visible }; continue
      }

      # XP
      if ($path -eq '/xp.json') {
        $days = 30; try { if ($req.QueryString['days']) { $days = [int]$req.QueryString['days'] } } catch {}
        Write-Json $res (Summarize-XP -Days $days); continue
      }
      if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $delta=[int]$b.delta; $reason="$($b.reason)"
        if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
        if (-not $reason) { $reason = 'Manual XP' }
        if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
          Add-OsXP -Amount $delta -Reason $reason | Out-Null
        } else {
          Initialize-OsStore
          $s = Get-OsStore
          $s.user.xp = [int]$s.user.xp + $delta
          Save-OsStore $s
        }
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # Missions
      if ($path -eq '/api/missions' -and $method -eq 'GET') {
        Initialize-OsStore
        $items = Get-OsMissions | ForEach-Object {
          [pscustomobject]@{ id="$($_.Id)"; title="$($_.Title)"; xp=[int]$_.XP; status="$($_.Status)" }
        }
        Write-Json $res @{ items = @($items) }; continue
      }
      if ($path -eq '/api/mission/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"; $title="$($b.title)"; $xp=[int]$b.xp
        if (-not $id)    { Write-Json $res @{ error="Missing id" } 400; continue }
        if (-not $title) { $title='New Mission' }
        Add-OsMission -Id $id -XP $xp -Title $title | Out-Null
        Write-Json $res @{ ok=$true; id=$id }; continue
      }
      if ($path -eq '/api/mission/complete' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"
        if (-not $id) { Write-Json $res @{ error='Missing id' } 400; continue }
        $null = Complete-OsMission -Id $id
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; id=$id; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # 404
      Write-Json $res @{ error = "Not found: $path" } 404
    } catch {
      try { Write-Json $ctx.Response @{ error = $_.Exception.Message } } catch {}
    }
  }
} finally { try { $listener.Stop(); $listener.Close() } catch {} }

_p   = $path
#requires -Version 7.0

# ==== BEGIN BP STORE FALLBACK (Initialize/Get/Save-OsStore) ====
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root = $root; dataDir = $dataDir; storePath = $storePath }
}

if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      $p = _bpStorePaths
      if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
      if (-not (Test-Path $p.storePath)) {
        '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}

if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $p = _bpStorePaths
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $p.storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $p.storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json
    } catch {
      $obj = ConvertFrom-Json '{"xp":{"events":[]}}'
      $obj | ConvertTo-Json -Depth 50 | Set-Content -Path $p.storePath -Encoding UTF8
    }
    if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $obj
  }
}

if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $p = _bpStorePaths
    Initialize-OsStore | Out-Null
    try {
      $json = $Store | ConvertTo-Json -Depth 50
      $json | Set-Content -Path $p.storePath -Encoding UTF8
      return $true
    } catch { return $false }
  }
}
# ==== END BP STORE FALLBACK ====

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'
$Mirror  = Join-Path $Www 'mirror.json'

. (Join-Path $Modules 'Osirisborn.Store.psm1')
. (Join-Path $Modules 'Osirisborn.XP.psm1')
. (Join-Path $Modules 'Osirisborn.Missions.psm1')

function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $res.StatusCode = $status
    $json  = ($obj | ConvertTo-Json -Depth 6)
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 6 } catch { return @{} }
}
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  return @{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  }
}

# Use 7780 to avoid any 7777 conflicts
$Port = 7780

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
# OSB: disabled opener -> Start-Process "http://localhost:$Port/"
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath
# ==== BEGIN LESSONS API GUARD (LESS-003) ====
# Defensive helpers
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 12 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpDataDir {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  [IO.Path]::GetFullPath((Join-Path $root "..\data"))
}
function _bpReadBody {
  $req = _bpGetReq
  if (-not $req) { return $null }
  try {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $s  = $sr.ReadToEnd(); $sr.Close(); return $s
  } catch { return $null }
}

# Short-circuit based on path (and method for POST)
$__p = $path
$__m = ( _bpGetReq )?.HttpMethod

if ($__p -eq "/api/lessons/summary") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    $tracks = @()

    if (Test-Path $currPath) {
      $curr = Get-Content $currPath -Raw | ConvertFrom-Json
      $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }

      foreach ($t in $curr.tracks) {
        $lessonsCount = 0
        foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
        $completed = 0
        if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
          $completed = @($prog.$($t.id).completedLessons).Count
        }
        $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
        $tracks += [PSCustomObject]@{
          id        = $t.id
          title     = $t.title
          lessons   = $lessonsCount
          completed = $completed
          progress  = $progress
        }
      }
    }

    _bpWriteJson ([PSCustomObject]@{ totalTracks = @($tracks).Count; tracks = $tracks })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-summary-failed" } 500
    continue
  }
}
elseif ($__p -like "/api/lessons/track/*") {
  try {
    $tid = $__p.Substring("/api/lessons/track/".Length)
    if ([string]::IsNullOrWhiteSpace($tid)) { _bpWriteJson @{ error="missing-track-id" } 400; continue }

    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    $completedSet = @{}
    if ($prog -and ($prog.PSObject.Properties.Name -contains $tid)) {
      foreach ($lid in $prog.$tid.completedLessons) { $completedSet[$lid] = $true }
    }

    $total = 0; $done = 0
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        $total++
        if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true -Force }
        else                                   {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
      }
    }
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }

    _bpWriteJson ([PSCustomObject]@{
      id       = $track.id
      title    = $track.title
      progress = $progress
      modules  = $track.modules
      totals   = @{ lessons = $total; completed = $done }
    })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-track-failed" } 500
    continue
  }
}
elseif ($__m -eq "POST" -and $__p -eq "/api/lessons/complete") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $body = _bpReadBody
    if (-not $body) { _bpWriteJson @{ error="missing-body" } 400; continue }
    try { $obj = $body | ConvertFrom-Json } catch { _bpWriteJson @{ error="bad-json" } 400; continue }

    $tid = $obj.trackId; $lid = $obj.lessonId
    if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) {
      _bpWriteJson @{ error="missing-params" } 400; continue
    }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    # Locate lesson and XP
    $foundLesson = $null
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        if ($l.id -eq $lid) { $foundLesson = $l; break }
      }
      if ($foundLesson) { break }
    }
    if (-not $foundLesson) { _bpWriteJson @{ error="lesson-not-found" } 404; continue }

    $xp = $foundLesson.xp
    if (-not $xp) { $xp = $track.xpPerLesson }
    if (-not $xp) { $xp = 10 }

    # Read or init progress
    if (Test-Path $progPath) { $prog = Get-Content $progPath -Raw | ConvertFrom-Json } else { $prog = @{} | ConvertTo-Json | ConvertFrom-Json }
    if (-not ($prog.PSObject.Properties.Name -contains $tid)) {
      $prog | Add-Member -NotePropertyName $tid -NotePropertyValue ( [PSCustomObject]@{ completedLessons = @() } ) -Force
    }

    $list = @($prog.$tid.completedLessons)
    $already = $false
    foreach ($x in $list) { if ($x -eq $lid) { $already = $true; break } }

    if ($already) {
      # compute current totals/progress
      $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
      $completed = @($prog.$tid.completedLessons).Count
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      _bpWriteJson @{ status="exists"; awarded=0; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
      continue
    }

    # Append, save
    $newList = @($prog.$tid.completedLessons + $lid)
    $prog.$tid.completedLessons = $newList
    # Persist to file
    $jsonOut = $prog | ConvertTo-Json -Depth 12
    $jsonOut | Set-Content -Path $progPath -Encoding UTF8

    # compute new totals/progress
    $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
    $completed = @($prog.$tid.completedLessons).Count
    $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }

    _bpWriteJson @{ status="ok"; awarded=$xp; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-complete-failed" } 500
    continue
  }
}
# ==== END LESSONS API GUARD (LESS-003) ====
      $method = $req.HttpMethod.ToUpperInvariant()

      # Static
# ---- XP: add (module-first, with safe fallback)
if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
  $b = Read-Body $req
  $delta  = [int]$b.delta
  $reason = [string]$b.reason
  if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
  if ([string]::IsNullOrWhiteSpace($reason)) { $reason = 'Manual XP' }

  $usedModules = $false
  try {
    if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
      Add-OsXP -Amount $delta -Reason $reason | Out-Null
      $usedModules = $true
    }
  } catch {}

  if (-not $usedModules) {
    # ---- minimal self-contained fallback (no Initialize-OsStore dependency)
    if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
    $storePath = Join-Path $DataDir 'store.plasma'
    if (!(Test-Path $storePath)) {
      $default = [pscustomobject]@{
        user = [pscustomobject]@{ xp=0; rank='Initiate'; alias='Osirisborn'; progressPct=0 }
        missions = [pscustomobject]@{ catalog=@{}; completed=@() }
        meta = [pscustomobject]@{ xpLog=@() }
        settings = [pscustomobject]@{ dailyGoal=300; notify=$true }
      }
      Set-Content -Path $storePath -Value ($default | ConvertTo-Json -Depth 6) -Encoding UTF8
    }
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $s.user.xp = [int]($s.user.xp) + $delta

    # rank & progress (same thresholds as CLI)
    $threshold = @{
      'Initiate'=0; 'Ghost'=200; 'Signal Diver'=600; 'Network Phantom'=1200; 'Redline Operative'=2000;
      'Shadow Architect'=3000; 'Spectral Engineer'=4500; 'Elite'=6500; 'Voidbreaker'=9000; 'God Tier: Osirisborn'=12000
    }
    $ranks = @('Initiate','Ghost','Signal Diver','Network Phantom','Redline Operative','Shadow Architect','Spectral Engineer','Elite','Voidbreaker','God Tier: Osirisborn')
    foreach($r in $ranks){ if ($s.user.xp -ge $threshold[$r]) { $s.user.rank=$r } }
    $curr = $threshold[$s.user.rank]
    $next = $threshold[$ranks[[Math]::Min($ranks.IndexOf($s.user.rank)+1, $ranks.Count-1)]]
    $span = [Math]::Max(1, $next-$curr)
    $s.user.progressPct = [int][Math]::Clamp(100*($s.user.xp-$curr)/$span,0,100)

    # log entry
    if (-not $s.meta) { $s | Add-Member meta ([pscustomobject]@{}) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member xpLog @() -Force }
    $s.meta.xpLog = @($s.meta.xpLog + [pscustomobject]@{
      at=(Get-Date).ToString('o'); delta=$delta; reason=$reason; total=[int]$s.user.xp; rank=$s.user.rank
    })

    Set-Content $storePath ($s | ConvertTo-Json -Depth 6) -Encoding UTF8
  }

  # respond with current xp/rank
  $xp = $null
  if (Get-Command Get-OsXP -ErrorAction SilentlyContinue) { $xp = Get-OsXP }
  if (-not $xp) {
    $storePath = Join-Path $DataDir 'store.plasma'
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $xp = [pscustomobject]@{ Rank=$s.user.rank; XP=[int]$s.user.xp; ProgressPct=[int]($s.user.progressPct) }
  }
  Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=[int]($xp.ProgressPct) }; continue
}
      
if     ($path -eq '/' -or $path -match '^/index\.html$') { Write-File $res (Join-Path $Www 'index.html') 'text/html; charset=utf-8'; continue }
      elseif ($path -match '^/client\.js$')                    { Write-File $res (Join-Path $Www 'client.js') 'application/javascript; charset=utf-8'; continue }
      elseif ($path -match '^/mirror\.json$' -and (Test-Path $Mirror)) { Write-File $res $Mirror 'application/json; charset=utf-8'; continue }

      # DIAG
      if ($path -eq '/diag') {
        $exists = @{
          store    = Test-Path (Join-Path $Modules 'Osirisborn.Store.psm1')
          xp       = Test-Path (Join-Path $Modules 'Osirisborn.XP.psm1')
          missions = Test-Path (Join-Path $Modules 'Osirisborn.Missions.psm1')
        }
        $visible = Get-Command Add-OsMission,Get-OsMissions,Complete-OsMission,Add-OsXP,Get-OsXP -ErrorAction SilentlyContinue |
                   Select-Object Name,ModuleName
        Write-Json $res @{ mode='module'; modulesPath=$Modules; exists=$exists; visible=$visible }; continue
      }

      # XP
      if ($path -eq '/xp.json') {
        $days = 30; try { if ($req.QueryString['days']) { $days = [int]$req.QueryString['days'] } } catch {}
        Write-Json $res (Summarize-XP -Days $days); continue
      }
      if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $delta=[int]$b.delta; $reason="$($b.reason)"
        if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
        if (-not $reason) { $reason = 'Manual XP' }
        if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
          Add-OsXP -Amount $delta -Reason $reason | Out-Null
        } else {
          Initialize-OsStore
          $s = Get-OsStore
          $s.user.xp = [int]$s.user.xp + $delta
          Save-OsStore $s
        }
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # Missions
      if ($path -eq '/api/missions' -and $method -eq 'GET') {
        Initialize-OsStore
        $items = Get-OsMissions | ForEach-Object {
          [pscustomobject]@{ id="$($_.Id)"; title="$($_.Title)"; xp=[int]$_.XP; status="$($_.Status)" }
        }
        Write-Json $res @{ items = @($items) }; continue
      }
      if ($path -eq '/api/mission/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"; $title="$($b.title)"; $xp=[int]$b.xp
        if (-not $id)    { Write-Json $res @{ error="Missing id" } 400; continue }
        if (-not $title) { $title='New Mission' }
        Add-OsMission -Id $id -XP $xp -Title $title | Out-Null
        Write-Json $res @{ ok=$true; id=$id }; continue
      }
      if ($path -eq '/api/mission/complete' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"
        if (-not $id) { Write-Json $res @{ error='Missing id' } 400; continue }
        $null = Complete-OsMission -Id $id
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; id=$id; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # 404
      Write-Json $res @{ error = "Not found: $path" } 404
    } catch {
      try { Write-Json $ctx.Response @{ error = $_.Exception.Message } } catch {}
    }
  }
} finally { try { $listener.Stop(); $listener.Close() } catch {} }

_m   = #requires -Version 7.0

# ==== BEGIN BP STORE FALLBACK (Initialize/Get/Save-OsStore) ====
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root = $root; dataDir = $dataDir; storePath = $storePath }
}

if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      $p = _bpStorePaths
      if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
      if (-not (Test-Path $p.storePath)) {
        '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}

if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $p = _bpStorePaths
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $p.storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $p.storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json
    } catch {
      $obj = ConvertFrom-Json '{"xp":{"events":[]}}'
      $obj | ConvertTo-Json -Depth 50 | Set-Content -Path $p.storePath -Encoding UTF8
    }
    if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $obj
  }
}

if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $p = _bpStorePaths
    Initialize-OsStore | Out-Null
    try {
      $json = $Store | ConvertTo-Json -Depth 50
      $json | Set-Content -Path $p.storePath -Encoding UTF8
      return $true
    } catch { return $false }
  }
}
# ==== END BP STORE FALLBACK ====

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'
$Mirror  = Join-Path $Www 'mirror.json'

. (Join-Path $Modules 'Osirisborn.Store.psm1')
. (Join-Path $Modules 'Osirisborn.XP.psm1')
. (Join-Path $Modules 'Osirisborn.Missions.psm1')

function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $res.StatusCode = $status
    $json  = ($obj | ConvertTo-Json -Depth 6)
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 6 } catch { return @{} }
}
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  return @{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  }
}

# Use 7780 to avoid any 7777 conflicts
$Port = 7780

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
# OSB: disabled opener -> Start-Process "http://localhost:$Port/"
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath
# ==== BEGIN LESSONS API GUARD (LESS-003) ====
# Defensive helpers
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 12 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpDataDir {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  [IO.Path]::GetFullPath((Join-Path $root "..\data"))
}
function _bpReadBody {
  $req = _bpGetReq
  if (-not $req) { return $null }
  try {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $s  = $sr.ReadToEnd(); $sr.Close(); return $s
  } catch { return $null }
}

# Short-circuit based on path (and method for POST)
$__p = $path
$__m = ( _bpGetReq )?.HttpMethod

if ($__p -eq "/api/lessons/summary") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    $tracks = @()

    if (Test-Path $currPath) {
      $curr = Get-Content $currPath -Raw | ConvertFrom-Json
      $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }

      foreach ($t in $curr.tracks) {
        $lessonsCount = 0
        foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
        $completed = 0
        if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
          $completed = @($prog.$($t.id).completedLessons).Count
        }
        $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
        $tracks += [PSCustomObject]@{
          id        = $t.id
          title     = $t.title
          lessons   = $lessonsCount
          completed = $completed
          progress  = $progress
        }
      }
    }

    _bpWriteJson ([PSCustomObject]@{ totalTracks = @($tracks).Count; tracks = $tracks })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-summary-failed" } 500
    continue
  }
}
elseif ($__p -like "/api/lessons/track/*") {
  try {
    $tid = $__p.Substring("/api/lessons/track/".Length)
    if ([string]::IsNullOrWhiteSpace($tid)) { _bpWriteJson @{ error="missing-track-id" } 400; continue }

    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    $completedSet = @{}
    if ($prog -and ($prog.PSObject.Properties.Name -contains $tid)) {
      foreach ($lid in $prog.$tid.completedLessons) { $completedSet[$lid] = $true }
    }

    $total = 0; $done = 0
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        $total++
        if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true -Force }
        else                                   {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
      }
    }
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }

    _bpWriteJson ([PSCustomObject]@{
      id       = $track.id
      title    = $track.title
      progress = $progress
      modules  = $track.modules
      totals   = @{ lessons = $total; completed = $done }
    })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-track-failed" } 500
    continue
  }
}
elseif ($__m -eq "POST" -and $__p -eq "/api/lessons/complete") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $body = _bpReadBody
    if (-not $body) { _bpWriteJson @{ error="missing-body" } 400; continue }
    try { $obj = $body | ConvertFrom-Json } catch { _bpWriteJson @{ error="bad-json" } 400; continue }

    $tid = $obj.trackId; $lid = $obj.lessonId
    if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) {
      _bpWriteJson @{ error="missing-params" } 400; continue
    }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    # Locate lesson and XP
    $foundLesson = $null
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        if ($l.id -eq $lid) { $foundLesson = $l; break }
      }
      if ($foundLesson) { break }
    }
    if (-not $foundLesson) { _bpWriteJson @{ error="lesson-not-found" } 404; continue }

    $xp = $foundLesson.xp
    if (-not $xp) { $xp = $track.xpPerLesson }
    if (-not $xp) { $xp = 10 }

    # Read or init progress
    if (Test-Path $progPath) { $prog = Get-Content $progPath -Raw | ConvertFrom-Json } else { $prog = @{} | ConvertTo-Json | ConvertFrom-Json }
    if (-not ($prog.PSObject.Properties.Name -contains $tid)) {
      $prog | Add-Member -NotePropertyName $tid -NotePropertyValue ( [PSCustomObject]@{ completedLessons = @() } ) -Force
    }

    $list = @($prog.$tid.completedLessons)
    $already = $false
    foreach ($x in $list) { if ($x -eq $lid) { $already = $true; break } }

    if ($already) {
      # compute current totals/progress
      $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
      $completed = @($prog.$tid.completedLessons).Count
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      _bpWriteJson @{ status="exists"; awarded=0; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
      continue
    }

    # Append, save
    $newList = @($prog.$tid.completedLessons + $lid)
    $prog.$tid.completedLessons = $newList
    # Persist to file
    $jsonOut = $prog | ConvertTo-Json -Depth 12
    $jsonOut | Set-Content -Path $progPath -Encoding UTF8

    # compute new totals/progress
    $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
    $completed = @($prog.$tid.completedLessons).Count
    $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }

    _bpWriteJson @{ status="ok"; awarded=$xp; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-complete-failed" } 500
    continue
  }
}
# ==== END LESSONS API GUARD (LESS-003) ====
      $method = $req.HttpMethod.ToUpperInvariant()

      # Static
# ---- XP: add (module-first, with safe fallback)
if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
  $b = Read-Body $req
  $delta  = [int]$b.delta
  $reason = [string]$b.reason
  if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
  if ([string]::IsNullOrWhiteSpace($reason)) { $reason = 'Manual XP' }

  $usedModules = $false
  try {
    if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
      Add-OsXP -Amount $delta -Reason $reason | Out-Null
      $usedModules = $true
    }
  } catch {}

  if (-not $usedModules) {
    # ---- minimal self-contained fallback (no Initialize-OsStore dependency)
    if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
    $storePath = Join-Path $DataDir 'store.plasma'
    if (!(Test-Path $storePath)) {
      $default = [pscustomobject]@{
        user = [pscustomobject]@{ xp=0; rank='Initiate'; alias='Osirisborn'; progressPct=0 }
        missions = [pscustomobject]@{ catalog=@{}; completed=@() }
        meta = [pscustomobject]@{ xpLog=@() }
        settings = [pscustomobject]@{ dailyGoal=300; notify=$true }
      }
      Set-Content -Path $storePath -Value ($default | ConvertTo-Json -Depth 6) -Encoding UTF8
    }
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $s.user.xp = [int]($s.user.xp) + $delta

    # rank & progress (same thresholds as CLI)
    $threshold = @{
      'Initiate'=0; 'Ghost'=200; 'Signal Diver'=600; 'Network Phantom'=1200; 'Redline Operative'=2000;
      'Shadow Architect'=3000; 'Spectral Engineer'=4500; 'Elite'=6500; 'Voidbreaker'=9000; 'God Tier: Osirisborn'=12000
    }
    $ranks = @('Initiate','Ghost','Signal Diver','Network Phantom','Redline Operative','Shadow Architect','Spectral Engineer','Elite','Voidbreaker','God Tier: Osirisborn')
    foreach($r in $ranks){ if ($s.user.xp -ge $threshold[$r]) { $s.user.rank=$r } }
    $curr = $threshold[$s.user.rank]
    $next = $threshold[$ranks[[Math]::Min($ranks.IndexOf($s.user.rank)+1, $ranks.Count-1)]]
    $span = [Math]::Max(1, $next-$curr)
    $s.user.progressPct = [int][Math]::Clamp(100*($s.user.xp-$curr)/$span,0,100)

    # log entry
    if (-not $s.meta) { $s | Add-Member meta ([pscustomobject]@{}) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member xpLog @() -Force }
    $s.meta.xpLog = @($s.meta.xpLog + [pscustomobject]@{
      at=(Get-Date).ToString('o'); delta=$delta; reason=$reason; total=[int]$s.user.xp; rank=$s.user.rank
    })

    Set-Content $storePath ($s | ConvertTo-Json -Depth 6) -Encoding UTF8
  }

  # respond with current xp/rank
  $xp = $null
  if (Get-Command Get-OsXP -ErrorAction SilentlyContinue) { $xp = Get-OsXP }
  if (-not $xp) {
    $storePath = Join-Path $DataDir 'store.plasma'
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $xp = [pscustomobject]@{ Rank=$s.user.rank; XP=[int]$s.user.xp; ProgressPct=[int]($s.user.progressPct) }
  }
  Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=[int]($xp.ProgressPct) }; continue
}
      
if     ($path -eq '/' -or $path -match '^/index\.html$') { Write-File $res (Join-Path $Www 'index.html') 'text/html; charset=utf-8'; continue }
      elseif ($path -match '^/client\.js$')                    { Write-File $res (Join-Path $Www 'client.js') 'application/javascript; charset=utf-8'; continue }
      elseif ($path -match '^/mirror\.json$' -and (Test-Path $Mirror)) { Write-File $res $Mirror 'application/json; charset=utf-8'; continue }

      # DIAG
      if ($path -eq '/diag') {
        $exists = @{
          store    = Test-Path (Join-Path $Modules 'Osirisborn.Store.psm1')
          xp       = Test-Path (Join-Path $Modules 'Osirisborn.XP.psm1')
          missions = Test-Path (Join-Path $Modules 'Osirisborn.Missions.psm1')
        }
        $visible = Get-Command Add-OsMission,Get-OsMissions,Complete-OsMission,Add-OsXP,Get-OsXP -ErrorAction SilentlyContinue |
                   Select-Object Name,ModuleName
        Write-Json $res @{ mode='module'; modulesPath=$Modules; exists=$exists; visible=$visible }; continue
      }

      # XP
      if ($path -eq '/xp.json') {
        $days = 30; try { if ($req.QueryString['days']) { $days = [int]$req.QueryString['days'] } } catch {}
        Write-Json $res (Summarize-XP -Days $days); continue
      }
      if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $delta=[int]$b.delta; $reason="$($b.reason)"
        if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
        if (-not $reason) { $reason = 'Manual XP' }
        if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
          Add-OsXP -Amount $delta -Reason $reason | Out-Null
        } else {
          Initialize-OsStore
          $s = Get-OsStore
          $s.user.xp = [int]$s.user.xp + $delta
          Save-OsStore $s
        }
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # Missions
      if ($path -eq '/api/missions' -and $method -eq 'GET') {
        Initialize-OsStore
        $items = Get-OsMissions | ForEach-Object {
          [pscustomobject]@{ id="$($_.Id)"; title="$($_.Title)"; xp=[int]$_.XP; status="$($_.Status)" }
        }
        Write-Json $res @{ items = @($items) }; continue
      }
      if ($path -eq '/api/mission/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"; $title="$($b.title)"; $xp=[int]$b.xp
        if (-not $id)    { Write-Json $res @{ error="Missing id" } 400; continue }
        if (-not $title) { $title='New Mission' }
        Add-OsMission -Id $id -XP $xp -Title $title | Out-Null
        Write-Json $res @{ ok=$true; id=$id }; continue
      }
      if ($path -eq '/api/mission/complete' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"
        if (-not $id) { Write-Json $res @{ error='Missing id' } 400; continue }
        $null = Complete-OsMission -Id $id
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; id=$id; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # 404
      Write-Json $res @{ error = "Not found: $path" } 404
    } catch {
      try { Write-Json $ctx.Response @{ error = $_.Exception.Message } } catch {}
    }
  }
} finally { try { $listener.Stop(); $listener.Close() } catch {} }

_req?.HttpMethod

# POST /api/xp/add  -- append XP event
if (#requires -Version 7.0

# ==== BEGIN BP STORE FALLBACK (Initialize/Get/Save-OsStore) ====
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root = $root; dataDir = $dataDir; storePath = $storePath }
}

if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      $p = _bpStorePaths
      if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
      if (-not (Test-Path $p.storePath)) {
        '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}

if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $p = _bpStorePaths
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $p.storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $p.storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json
    } catch {
      $obj = ConvertFrom-Json '{"xp":{"events":[]}}'
      $obj | ConvertTo-Json -Depth 50 | Set-Content -Path $p.storePath -Encoding UTF8
    }
    if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $obj
  }
}

if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $p = _bpStorePaths
    Initialize-OsStore | Out-Null
    try {
      $json = $Store | ConvertTo-Json -Depth 50
      $json | Set-Content -Path $p.storePath -Encoding UTF8
      return $true
    } catch { return $false }
  }
}
# ==== END BP STORE FALLBACK ====

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'
$Mirror  = Join-Path $Www 'mirror.json'

. (Join-Path $Modules 'Osirisborn.Store.psm1')
. (Join-Path $Modules 'Osirisborn.XP.psm1')
. (Join-Path $Modules 'Osirisborn.Missions.psm1')

function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $res.StatusCode = $status
    $json  = ($obj | ConvertTo-Json -Depth 6)
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 6 } catch { return @{} }
}
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  return @{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  }
}

# Use 7780 to avoid any 7777 conflicts
$Port = 7780

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
# OSB: disabled opener -> Start-Process "http://localhost:$Port/"
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath
# ==== BEGIN LESSONS API GUARD (LESS-003) ====
# Defensive helpers
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 12 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpDataDir {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  [IO.Path]::GetFullPath((Join-Path $root "..\data"))
}
function _bpReadBody {
  $req = _bpGetReq
  if (-not $req) { return $null }
  try {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $s  = $sr.ReadToEnd(); $sr.Close(); return $s
  } catch { return $null }
}

# Short-circuit based on path (and method for POST)
$__p = $path
$__m = ( _bpGetReq )?.HttpMethod

if ($__p -eq "/api/lessons/summary") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    $tracks = @()

    if (Test-Path $currPath) {
      $curr = Get-Content $currPath -Raw | ConvertFrom-Json
      $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }

      foreach ($t in $curr.tracks) {
        $lessonsCount = 0
        foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
        $completed = 0
        if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
          $completed = @($prog.$($t.id).completedLessons).Count
        }
        $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
        $tracks += [PSCustomObject]@{
          id        = $t.id
          title     = $t.title
          lessons   = $lessonsCount
          completed = $completed
          progress  = $progress
        }
      }
    }

    _bpWriteJson ([PSCustomObject]@{ totalTracks = @($tracks).Count; tracks = $tracks })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-summary-failed" } 500
    continue
  }
}
elseif ($__p -like "/api/lessons/track/*") {
  try {
    $tid = $__p.Substring("/api/lessons/track/".Length)
    if ([string]::IsNullOrWhiteSpace($tid)) { _bpWriteJson @{ error="missing-track-id" } 400; continue }

    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    $completedSet = @{}
    if ($prog -and ($prog.PSObject.Properties.Name -contains $tid)) {
      foreach ($lid in $prog.$tid.completedLessons) { $completedSet[$lid] = $true }
    }

    $total = 0; $done = 0
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        $total++
        if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true -Force }
        else                                   {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
      }
    }
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }

    _bpWriteJson ([PSCustomObject]@{
      id       = $track.id
      title    = $track.title
      progress = $progress
      modules  = $track.modules
      totals   = @{ lessons = $total; completed = $done }
    })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-track-failed" } 500
    continue
  }
}
elseif ($__m -eq "POST" -and $__p -eq "/api/lessons/complete") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $body = _bpReadBody
    if (-not $body) { _bpWriteJson @{ error="missing-body" } 400; continue }
    try { $obj = $body | ConvertFrom-Json } catch { _bpWriteJson @{ error="bad-json" } 400; continue }

    $tid = $obj.trackId; $lid = $obj.lessonId
    if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) {
      _bpWriteJson @{ error="missing-params" } 400; continue
    }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    # Locate lesson and XP
    $foundLesson = $null
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        if ($l.id -eq $lid) { $foundLesson = $l; break }
      }
      if ($foundLesson) { break }
    }
    if (-not $foundLesson) { _bpWriteJson @{ error="lesson-not-found" } 404; continue }

    $xp = $foundLesson.xp
    if (-not $xp) { $xp = $track.xpPerLesson }
    if (-not $xp) { $xp = 10 }

    # Read or init progress
    if (Test-Path $progPath) { $prog = Get-Content $progPath -Raw | ConvertFrom-Json } else { $prog = @{} | ConvertTo-Json | ConvertFrom-Json }
    if (-not ($prog.PSObject.Properties.Name -contains $tid)) {
      $prog | Add-Member -NotePropertyName $tid -NotePropertyValue ( [PSCustomObject]@{ completedLessons = @() } ) -Force
    }

    $list = @($prog.$tid.completedLessons)
    $already = $false
    foreach ($x in $list) { if ($x -eq $lid) { $already = $true; break } }

    if ($already) {
      # compute current totals/progress
      $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
      $completed = @($prog.$tid.completedLessons).Count
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      _bpWriteJson @{ status="exists"; awarded=0; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
      continue
    }

    # Append, save
    $newList = @($prog.$tid.completedLessons + $lid)
    $prog.$tid.completedLessons = $newList
    # Persist to file
    $jsonOut = $prog | ConvertTo-Json -Depth 12
    $jsonOut | Set-Content -Path $progPath -Encoding UTF8

    # compute new totals/progress
    $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
    $completed = @($prog.$tid.completedLessons).Count
    $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }

    _bpWriteJson @{ status="ok"; awarded=$xp; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-complete-failed" } 500
    continue
  }
}
# ==== END LESSONS API GUARD (LESS-003) ====
      $method = $req.HttpMethod.ToUpperInvariant()

      # Static
# ---- XP: add (module-first, with safe fallback)
if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
  $b = Read-Body $req
  $delta  = [int]$b.delta
  $reason = [string]$b.reason
  if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
  if ([string]::IsNullOrWhiteSpace($reason)) { $reason = 'Manual XP' }

  $usedModules = $false
  try {
    if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
      Add-OsXP -Amount $delta -Reason $reason | Out-Null
      $usedModules = $true
    }
  } catch {}

  if (-not $usedModules) {
    # ---- minimal self-contained fallback (no Initialize-OsStore dependency)
    if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
    $storePath = Join-Path $DataDir 'store.plasma'
    if (!(Test-Path $storePath)) {
      $default = [pscustomobject]@{
        user = [pscustomobject]@{ xp=0; rank='Initiate'; alias='Osirisborn'; progressPct=0 }
        missions = [pscustomobject]@{ catalog=@{}; completed=@() }
        meta = [pscustomobject]@{ xpLog=@() }
        settings = [pscustomobject]@{ dailyGoal=300; notify=$true }
      }
      Set-Content -Path $storePath -Value ($default | ConvertTo-Json -Depth 6) -Encoding UTF8
    }
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $s.user.xp = [int]($s.user.xp) + $delta

    # rank & progress (same thresholds as CLI)
    $threshold = @{
      'Initiate'=0; 'Ghost'=200; 'Signal Diver'=600; 'Network Phantom'=1200; 'Redline Operative'=2000;
      'Shadow Architect'=3000; 'Spectral Engineer'=4500; 'Elite'=6500; 'Voidbreaker'=9000; 'God Tier: Osirisborn'=12000
    }
    $ranks = @('Initiate','Ghost','Signal Diver','Network Phantom','Redline Operative','Shadow Architect','Spectral Engineer','Elite','Voidbreaker','God Tier: Osirisborn')
    foreach($r in $ranks){ if ($s.user.xp -ge $threshold[$r]) { $s.user.rank=$r } }
    $curr = $threshold[$s.user.rank]
    $next = $threshold[$ranks[[Math]::Min($ranks.IndexOf($s.user.rank)+1, $ranks.Count-1)]]
    $span = [Math]::Max(1, $next-$curr)
    $s.user.progressPct = [int][Math]::Clamp(100*($s.user.xp-$curr)/$span,0,100)

    # log entry
    if (-not $s.meta) { $s | Add-Member meta ([pscustomobject]@{}) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member xpLog @() -Force }
    $s.meta.xpLog = @($s.meta.xpLog + [pscustomobject]@{
      at=(Get-Date).ToString('o'); delta=$delta; reason=$reason; total=[int]$s.user.xp; rank=$s.user.rank
    })

    Set-Content $storePath ($s | ConvertTo-Json -Depth 6) -Encoding UTF8
  }

  # respond with current xp/rank
  $xp = $null
  if (Get-Command Get-OsXP -ErrorAction SilentlyContinue) { $xp = Get-OsXP }
  if (-not $xp) {
    $storePath = Join-Path $DataDir 'store.plasma'
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $xp = [pscustomobject]@{ Rank=$s.user.rank; XP=[int]$s.user.xp; ProgressPct=[int]($s.user.progressPct) }
  }
  Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=[int]($xp.ProgressPct) }; continue
}
      
if     ($path -eq '/' -or $path -match '^/index\.html$') { Write-File $res (Join-Path $Www 'index.html') 'text/html; charset=utf-8'; continue }
      elseif ($path -match '^/client\.js$')                    { Write-File $res (Join-Path $Www 'client.js') 'application/javascript; charset=utf-8'; continue }
      elseif ($path -match '^/mirror\.json$' -and (Test-Path $Mirror)) { Write-File $res $Mirror 'application/json; charset=utf-8'; continue }

      # DIAG
      if ($path -eq '/diag') {
        $exists = @{
          store    = Test-Path (Join-Path $Modules 'Osirisborn.Store.psm1')
          xp       = Test-Path (Join-Path $Modules 'Osirisborn.XP.psm1')
          missions = Test-Path (Join-Path $Modules 'Osirisborn.Missions.psm1')
        }
        $visible = Get-Command Add-OsMission,Get-OsMissions,Complete-OsMission,Add-OsXP,Get-OsXP -ErrorAction SilentlyContinue |
                   Select-Object Name,ModuleName
        Write-Json $res @{ mode='module'; modulesPath=$Modules; exists=$exists; visible=$visible }; continue
      }

      # XP
      if ($path -eq '/xp.json') {
        $days = 30; try { if ($req.QueryString['days']) { $days = [int]$req.QueryString['days'] } } catch {}
        Write-Json $res (Summarize-XP -Days $days); continue
      }
      if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $delta=[int]$b.delta; $reason="$($b.reason)"
        if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
        if (-not $reason) { $reason = 'Manual XP' }
        if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
          Add-OsXP -Amount $delta -Reason $reason | Out-Null
        } else {
          Initialize-OsStore
          $s = Get-OsStore
          $s.user.xp = [int]$s.user.xp + $delta
          Save-OsStore $s
        }
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # Missions
      if ($path -eq '/api/missions' -and $method -eq 'GET') {
        Initialize-OsStore
        $items = Get-OsMissions | ForEach-Object {
          [pscustomobject]@{ id="$($_.Id)"; title="$($_.Title)"; xp=[int]$_.XP; status="$($_.Status)" }
        }
        Write-Json $res @{ items = @($items) }; continue
      }
      if ($path -eq '/api/mission/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"; $title="$($b.title)"; $xp=[int]$b.xp
        if (-not $id)    { Write-Json $res @{ error="Missing id" } 400; continue }
        if (-not $title) { $title='New Mission' }
        Add-OsMission -Id $id -XP $xp -Title $title | Out-Null
        Write-Json $res @{ ok=$true; id=$id }; continue
      }
      if ($path -eq '/api/mission/complete' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"
        if (-not $id) { Write-Json $res @{ error='Missing id' } 400; continue }
        $null = Complete-OsMission -Id $id
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; id=$id; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # 404
      Write-Json $res @{ error = "Not found: $path" } 404
    } catch {
      try { Write-Json $ctx.Response @{ error = $_.Exception.Message } } catch {}
    }
  }
} finally { try { $listener.Stop(); $listener.Close() } catch {} }

_m -eq "POST" -and #requires -Version 7.0

# ==== BEGIN BP STORE FALLBACK (Initialize/Get/Save-OsStore) ====
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root = $root; dataDir = $dataDir; storePath = $storePath }
}

if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      $p = _bpStorePaths
      if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
      if (-not (Test-Path $p.storePath)) {
        '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}

if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $p = _bpStorePaths
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $p.storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $p.storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json
    } catch {
      $obj = ConvertFrom-Json '{"xp":{"events":[]}}'
      $obj | ConvertTo-Json -Depth 50 | Set-Content -Path $p.storePath -Encoding UTF8
    }
    if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $obj
  }
}

if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $p = _bpStorePaths
    Initialize-OsStore | Out-Null
    try {
      $json = $Store | ConvertTo-Json -Depth 50
      $json | Set-Content -Path $p.storePath -Encoding UTF8
      return $true
    } catch { return $false }
  }
}
# ==== END BP STORE FALLBACK ====

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'
$Mirror  = Join-Path $Www 'mirror.json'

. (Join-Path $Modules 'Osirisborn.Store.psm1')
. (Join-Path $Modules 'Osirisborn.XP.psm1')
. (Join-Path $Modules 'Osirisborn.Missions.psm1')

function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $res.StatusCode = $status
    $json  = ($obj | ConvertTo-Json -Depth 6)
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 6 } catch { return @{} }
}
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  return @{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  }
}

# Use 7780 to avoid any 7777 conflicts
$Port = 7780

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
# OSB: disabled opener -> Start-Process "http://localhost:$Port/"
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath
# ==== BEGIN LESSONS API GUARD (LESS-003) ====
# Defensive helpers
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 12 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpDataDir {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  [IO.Path]::GetFullPath((Join-Path $root "..\data"))
}
function _bpReadBody {
  $req = _bpGetReq
  if (-not $req) { return $null }
  try {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $s  = $sr.ReadToEnd(); $sr.Close(); return $s
  } catch { return $null }
}

# Short-circuit based on path (and method for POST)
$__p = $path
$__m = ( _bpGetReq )?.HttpMethod

if ($__p -eq "/api/lessons/summary") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    $tracks = @()

    if (Test-Path $currPath) {
      $curr = Get-Content $currPath -Raw | ConvertFrom-Json
      $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }

      foreach ($t in $curr.tracks) {
        $lessonsCount = 0
        foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
        $completed = 0
        if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
          $completed = @($prog.$($t.id).completedLessons).Count
        }
        $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
        $tracks += [PSCustomObject]@{
          id        = $t.id
          title     = $t.title
          lessons   = $lessonsCount
          completed = $completed
          progress  = $progress
        }
      }
    }

    _bpWriteJson ([PSCustomObject]@{ totalTracks = @($tracks).Count; tracks = $tracks })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-summary-failed" } 500
    continue
  }
}
elseif ($__p -like "/api/lessons/track/*") {
  try {
    $tid = $__p.Substring("/api/lessons/track/".Length)
    if ([string]::IsNullOrWhiteSpace($tid)) { _bpWriteJson @{ error="missing-track-id" } 400; continue }

    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    $completedSet = @{}
    if ($prog -and ($prog.PSObject.Properties.Name -contains $tid)) {
      foreach ($lid in $prog.$tid.completedLessons) { $completedSet[$lid] = $true }
    }

    $total = 0; $done = 0
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        $total++
        if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true -Force }
        else                                   {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
      }
    }
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }

    _bpWriteJson ([PSCustomObject]@{
      id       = $track.id
      title    = $track.title
      progress = $progress
      modules  = $track.modules
      totals   = @{ lessons = $total; completed = $done }
    })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-track-failed" } 500
    continue
  }
}
elseif ($__m -eq "POST" -and $__p -eq "/api/lessons/complete") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $body = _bpReadBody
    if (-not $body) { _bpWriteJson @{ error="missing-body" } 400; continue }
    try { $obj = $body | ConvertFrom-Json } catch { _bpWriteJson @{ error="bad-json" } 400; continue }

    $tid = $obj.trackId; $lid = $obj.lessonId
    if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) {
      _bpWriteJson @{ error="missing-params" } 400; continue
    }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    # Locate lesson and XP
    $foundLesson = $null
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        if ($l.id -eq $lid) { $foundLesson = $l; break }
      }
      if ($foundLesson) { break }
    }
    if (-not $foundLesson) { _bpWriteJson @{ error="lesson-not-found" } 404; continue }

    $xp = $foundLesson.xp
    if (-not $xp) { $xp = $track.xpPerLesson }
    if (-not $xp) { $xp = 10 }

    # Read or init progress
    if (Test-Path $progPath) { $prog = Get-Content $progPath -Raw | ConvertFrom-Json } else { $prog = @{} | ConvertTo-Json | ConvertFrom-Json }
    if (-not ($prog.PSObject.Properties.Name -contains $tid)) {
      $prog | Add-Member -NotePropertyName $tid -NotePropertyValue ( [PSCustomObject]@{ completedLessons = @() } ) -Force
    }

    $list = @($prog.$tid.completedLessons)
    $already = $false
    foreach ($x in $list) { if ($x -eq $lid) { $already = $true; break } }

    if ($already) {
      # compute current totals/progress
      $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
      $completed = @($prog.$tid.completedLessons).Count
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      _bpWriteJson @{ status="exists"; awarded=0; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
      continue
    }

    # Append, save
    $newList = @($prog.$tid.completedLessons + $lid)
    $prog.$tid.completedLessons = $newList
    # Persist to file
    $jsonOut = $prog | ConvertTo-Json -Depth 12
    $jsonOut | Set-Content -Path $progPath -Encoding UTF8

    # compute new totals/progress
    $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
    $completed = @($prog.$tid.completedLessons).Count
    $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }

    _bpWriteJson @{ status="ok"; awarded=$xp; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-complete-failed" } 500
    continue
  }
}
# ==== END LESSONS API GUARD (LESS-003) ====
      $method = $req.HttpMethod.ToUpperInvariant()

      # Static
# ---- XP: add (module-first, with safe fallback)
if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
  $b = Read-Body $req
  $delta  = [int]$b.delta
  $reason = [string]$b.reason
  if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
  if ([string]::IsNullOrWhiteSpace($reason)) { $reason = 'Manual XP' }

  $usedModules = $false
  try {
    if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
      Add-OsXP -Amount $delta -Reason $reason | Out-Null
      $usedModules = $true
    }
  } catch {}

  if (-not $usedModules) {
    # ---- minimal self-contained fallback (no Initialize-OsStore dependency)
    if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
    $storePath = Join-Path $DataDir 'store.plasma'
    if (!(Test-Path $storePath)) {
      $default = [pscustomobject]@{
        user = [pscustomobject]@{ xp=0; rank='Initiate'; alias='Osirisborn'; progressPct=0 }
        missions = [pscustomobject]@{ catalog=@{}; completed=@() }
        meta = [pscustomobject]@{ xpLog=@() }
        settings = [pscustomobject]@{ dailyGoal=300; notify=$true }
      }
      Set-Content -Path $storePath -Value ($default | ConvertTo-Json -Depth 6) -Encoding UTF8
    }
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $s.user.xp = [int]($s.user.xp) + $delta

    # rank & progress (same thresholds as CLI)
    $threshold = @{
      'Initiate'=0; 'Ghost'=200; 'Signal Diver'=600; 'Network Phantom'=1200; 'Redline Operative'=2000;
      'Shadow Architect'=3000; 'Spectral Engineer'=4500; 'Elite'=6500; 'Voidbreaker'=9000; 'God Tier: Osirisborn'=12000
    }
    $ranks = @('Initiate','Ghost','Signal Diver','Network Phantom','Redline Operative','Shadow Architect','Spectral Engineer','Elite','Voidbreaker','God Tier: Osirisborn')
    foreach($r in $ranks){ if ($s.user.xp -ge $threshold[$r]) { $s.user.rank=$r } }
    $curr = $threshold[$s.user.rank]
    $next = $threshold[$ranks[[Math]::Min($ranks.IndexOf($s.user.rank)+1, $ranks.Count-1)]]
    $span = [Math]::Max(1, $next-$curr)
    $s.user.progressPct = [int][Math]::Clamp(100*($s.user.xp-$curr)/$span,0,100)

    # log entry
    if (-not $s.meta) { $s | Add-Member meta ([pscustomobject]@{}) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member xpLog @() -Force }
    $s.meta.xpLog = @($s.meta.xpLog + [pscustomobject]@{
      at=(Get-Date).ToString('o'); delta=$delta; reason=$reason; total=[int]$s.user.xp; rank=$s.user.rank
    })

    Set-Content $storePath ($s | ConvertTo-Json -Depth 6) -Encoding UTF8
  }

  # respond with current xp/rank
  $xp = $null
  if (Get-Command Get-OsXP -ErrorAction SilentlyContinue) { $xp = Get-OsXP }
  if (-not $xp) {
    $storePath = Join-Path $DataDir 'store.plasma'
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $xp = [pscustomobject]@{ Rank=$s.user.rank; XP=[int]$s.user.xp; ProgressPct=[int]($s.user.progressPct) }
  }
  Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=[int]($xp.ProgressPct) }; continue
}
      
if     ($path -eq '/' -or $path -match '^/index\.html$') { Write-File $res (Join-Path $Www 'index.html') 'text/html; charset=utf-8'; continue }
      elseif ($path -match '^/client\.js$')                    { Write-File $res (Join-Path $Www 'client.js') 'application/javascript; charset=utf-8'; continue }
      elseif ($path -match '^/mirror\.json$' -and (Test-Path $Mirror)) { Write-File $res $Mirror 'application/json; charset=utf-8'; continue }

      # DIAG
      if ($path -eq '/diag') {
        $exists = @{
          store    = Test-Path (Join-Path $Modules 'Osirisborn.Store.psm1')
          xp       = Test-Path (Join-Path $Modules 'Osirisborn.XP.psm1')
          missions = Test-Path (Join-Path $Modules 'Osirisborn.Missions.psm1')
        }
        $visible = Get-Command Add-OsMission,Get-OsMissions,Complete-OsMission,Add-OsXP,Get-OsXP -ErrorAction SilentlyContinue |
                   Select-Object Name,ModuleName
        Write-Json $res @{ mode='module'; modulesPath=$Modules; exists=$exists; visible=$visible }; continue
      }

      # XP
      if ($path -eq '/xp.json') {
        $days = 30; try { if ($req.QueryString['days']) { $days = [int]$req.QueryString['days'] } } catch {}
        Write-Json $res (Summarize-XP -Days $days); continue
      }
      if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $delta=[int]$b.delta; $reason="$($b.reason)"
        if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
        if (-not $reason) { $reason = 'Manual XP' }
        if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
          Add-OsXP -Amount $delta -Reason $reason | Out-Null
        } else {
          Initialize-OsStore
          $s = Get-OsStore
          $s.user.xp = [int]$s.user.xp + $delta
          Save-OsStore $s
        }
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # Missions
      if ($path -eq '/api/missions' -and $method -eq 'GET') {
        Initialize-OsStore
        $items = Get-OsMissions | ForEach-Object {
          [pscustomobject]@{ id="$($_.Id)"; title="$($_.Title)"; xp=[int]$_.XP; status="$($_.Status)" }
        }
        Write-Json $res @{ items = @($items) }; continue
      }
      if ($path -eq '/api/mission/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"; $title="$($b.title)"; $xp=[int]$b.xp
        if (-not $id)    { Write-Json $res @{ error="Missing id" } 400; continue }
        if (-not $title) { $title='New Mission' }
        Add-OsMission -Id $id -XP $xp -Title $title | Out-Null
        Write-Json $res @{ ok=$true; id=$id }; continue
      }
      if ($path -eq '/api/mission/complete' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"
        if (-not $id) { Write-Json $res @{ error='Missing id' } 400; continue }
        $null = Complete-OsMission -Id $id
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; id=$id; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # 404
      Write-Json $res @{ error = "Not found: $path" } 404
    } catch {
      try { Write-Json $ctx.Response @{ error = $_.Exception.Message } } catch {}
    }
  }
} finally { try { $listener.Stop(); $listener.Close() } catch {} }

_p -eq "/api/xp/add") {
  try {
    $body = (New-Object IO.StreamReader(#requires -Version 7.0

# ==== BEGIN BP STORE FALLBACK (Initialize/Get/Save-OsStore) ====
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root = $root; dataDir = $dataDir; storePath = $storePath }
}

if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      $p = _bpStorePaths
      if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
      if (-not (Test-Path $p.storePath)) {
        '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}

if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $p = _bpStorePaths
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $p.storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $p.storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json
    } catch {
      $obj = ConvertFrom-Json '{"xp":{"events":[]}}'
      $obj | ConvertTo-Json -Depth 50 | Set-Content -Path $p.storePath -Encoding UTF8
    }
    if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $obj
  }
}

if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $p = _bpStorePaths
    Initialize-OsStore | Out-Null
    try {
      $json = $Store | ConvertTo-Json -Depth 50
      $json | Set-Content -Path $p.storePath -Encoding UTF8
      return $true
    } catch { return $false }
  }
}
# ==== END BP STORE FALLBACK ====

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'
$Mirror  = Join-Path $Www 'mirror.json'

. (Join-Path $Modules 'Osirisborn.Store.psm1')
. (Join-Path $Modules 'Osirisborn.XP.psm1')
. (Join-Path $Modules 'Osirisborn.Missions.psm1')

function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $res.StatusCode = $status
    $json  = ($obj | ConvertTo-Json -Depth 6)
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 6 } catch { return @{} }
}
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  return @{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  }
}

# Use 7780 to avoid any 7777 conflicts
$Port = 7780

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
# OSB: disabled opener -> Start-Process "http://localhost:$Port/"
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath
# ==== BEGIN LESSONS API GUARD (LESS-003) ====
# Defensive helpers
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 12 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpDataDir {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  [IO.Path]::GetFullPath((Join-Path $root "..\data"))
}
function _bpReadBody {
  $req = _bpGetReq
  if (-not $req) { return $null }
  try {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $s  = $sr.ReadToEnd(); $sr.Close(); return $s
  } catch { return $null }
}

# Short-circuit based on path (and method for POST)
$__p = $path
$__m = ( _bpGetReq )?.HttpMethod

if ($__p -eq "/api/lessons/summary") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    $tracks = @()

    if (Test-Path $currPath) {
      $curr = Get-Content $currPath -Raw | ConvertFrom-Json
      $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }

      foreach ($t in $curr.tracks) {
        $lessonsCount = 0
        foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
        $completed = 0
        if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
          $completed = @($prog.$($t.id).completedLessons).Count
        }
        $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
        $tracks += [PSCustomObject]@{
          id        = $t.id
          title     = $t.title
          lessons   = $lessonsCount
          completed = $completed
          progress  = $progress
        }
      }
    }

    _bpWriteJson ([PSCustomObject]@{ totalTracks = @($tracks).Count; tracks = $tracks })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-summary-failed" } 500
    continue
  }
}
elseif ($__p -like "/api/lessons/track/*") {
  try {
    $tid = $__p.Substring("/api/lessons/track/".Length)
    if ([string]::IsNullOrWhiteSpace($tid)) { _bpWriteJson @{ error="missing-track-id" } 400; continue }

    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    $completedSet = @{}
    if ($prog -and ($prog.PSObject.Properties.Name -contains $tid)) {
      foreach ($lid in $prog.$tid.completedLessons) { $completedSet[$lid] = $true }
    }

    $total = 0; $done = 0
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        $total++
        if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true -Force }
        else                                   {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
      }
    }
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }

    _bpWriteJson ([PSCustomObject]@{
      id       = $track.id
      title    = $track.title
      progress = $progress
      modules  = $track.modules
      totals   = @{ lessons = $total; completed = $done }
    })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-track-failed" } 500
    continue
  }
}
elseif ($__m -eq "POST" -and $__p -eq "/api/lessons/complete") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $body = _bpReadBody
    if (-not $body) { _bpWriteJson @{ error="missing-body" } 400; continue }
    try { $obj = $body | ConvertFrom-Json } catch { _bpWriteJson @{ error="bad-json" } 400; continue }

    $tid = $obj.trackId; $lid = $obj.lessonId
    if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) {
      _bpWriteJson @{ error="missing-params" } 400; continue
    }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    # Locate lesson and XP
    $foundLesson = $null
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        if ($l.id -eq $lid) { $foundLesson = $l; break }
      }
      if ($foundLesson) { break }
    }
    if (-not $foundLesson) { _bpWriteJson @{ error="lesson-not-found" } 404; continue }

    $xp = $foundLesson.xp
    if (-not $xp) { $xp = $track.xpPerLesson }
    if (-not $xp) { $xp = 10 }

    # Read or init progress
    if (Test-Path $progPath) { $prog = Get-Content $progPath -Raw | ConvertFrom-Json } else { $prog = @{} | ConvertTo-Json | ConvertFrom-Json }
    if (-not ($prog.PSObject.Properties.Name -contains $tid)) {
      $prog | Add-Member -NotePropertyName $tid -NotePropertyValue ( [PSCustomObject]@{ completedLessons = @() } ) -Force
    }

    $list = @($prog.$tid.completedLessons)
    $already = $false
    foreach ($x in $list) { if ($x -eq $lid) { $already = $true; break } }

    if ($already) {
      # compute current totals/progress
      $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
      $completed = @($prog.$tid.completedLessons).Count
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      _bpWriteJson @{ status="exists"; awarded=0; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
      continue
    }

    # Append, save
    $newList = @($prog.$tid.completedLessons + $lid)
    $prog.$tid.completedLessons = $newList
    # Persist to file
    $jsonOut = $prog | ConvertTo-Json -Depth 12
    $jsonOut | Set-Content -Path $progPath -Encoding UTF8

    # compute new totals/progress
    $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
    $completed = @($prog.$tid.completedLessons).Count
    $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }

    _bpWriteJson @{ status="ok"; awarded=$xp; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-complete-failed" } 500
    continue
  }
}
# ==== END LESSONS API GUARD (LESS-003) ====
      $method = $req.HttpMethod.ToUpperInvariant()

      # Static
# ---- XP: add (module-first, with safe fallback)
if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
  $b = Read-Body $req
  $delta  = [int]$b.delta
  $reason = [string]$b.reason
  if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
  if ([string]::IsNullOrWhiteSpace($reason)) { $reason = 'Manual XP' }

  $usedModules = $false
  try {
    if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
      Add-OsXP -Amount $delta -Reason $reason | Out-Null
      $usedModules = $true
    }
  } catch {}

  if (-not $usedModules) {
    # ---- minimal self-contained fallback (no Initialize-OsStore dependency)
    if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
    $storePath = Join-Path $DataDir 'store.plasma'
    if (!(Test-Path $storePath)) {
      $default = [pscustomobject]@{
        user = [pscustomobject]@{ xp=0; rank='Initiate'; alias='Osirisborn'; progressPct=0 }
        missions = [pscustomobject]@{ catalog=@{}; completed=@() }
        meta = [pscustomobject]@{ xpLog=@() }
        settings = [pscustomobject]@{ dailyGoal=300; notify=$true }
      }
      Set-Content -Path $storePath -Value ($default | ConvertTo-Json -Depth 6) -Encoding UTF8
    }
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $s.user.xp = [int]($s.user.xp) + $delta

    # rank & progress (same thresholds as CLI)
    $threshold = @{
      'Initiate'=0; 'Ghost'=200; 'Signal Diver'=600; 'Network Phantom'=1200; 'Redline Operative'=2000;
      'Shadow Architect'=3000; 'Spectral Engineer'=4500; 'Elite'=6500; 'Voidbreaker'=9000; 'God Tier: Osirisborn'=12000
    }
    $ranks = @('Initiate','Ghost','Signal Diver','Network Phantom','Redline Operative','Shadow Architect','Spectral Engineer','Elite','Voidbreaker','God Tier: Osirisborn')
    foreach($r in $ranks){ if ($s.user.xp -ge $threshold[$r]) { $s.user.rank=$r } }
    $curr = $threshold[$s.user.rank]
    $next = $threshold[$ranks[[Math]::Min($ranks.IndexOf($s.user.rank)+1, $ranks.Count-1)]]
    $span = [Math]::Max(1, $next-$curr)
    $s.user.progressPct = [int][Math]::Clamp(100*($s.user.xp-$curr)/$span,0,100)

    # log entry
    if (-not $s.meta) { $s | Add-Member meta ([pscustomobject]@{}) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member xpLog @() -Force }
    $s.meta.xpLog = @($s.meta.xpLog + [pscustomobject]@{
      at=(Get-Date).ToString('o'); delta=$delta; reason=$reason; total=[int]$s.user.xp; rank=$s.user.rank
    })

    Set-Content $storePath ($s | ConvertTo-Json -Depth 6) -Encoding UTF8
  }

  # respond with current xp/rank
  $xp = $null
  if (Get-Command Get-OsXP -ErrorAction SilentlyContinue) { $xp = Get-OsXP }
  if (-not $xp) {
    $storePath = Join-Path $DataDir 'store.plasma'
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $xp = [pscustomobject]@{ Rank=$s.user.rank; XP=[int]$s.user.xp; ProgressPct=[int]($s.user.progressPct) }
  }
  Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=[int]($xp.ProgressPct) }; continue
}
      
if     ($path -eq '/' -or $path -match '^/index\.html$') { Write-File $res (Join-Path $Www 'index.html') 'text/html; charset=utf-8'; continue }
      elseif ($path -match '^/client\.js$')                    { Write-File $res (Join-Path $Www 'client.js') 'application/javascript; charset=utf-8'; continue }
      elseif ($path -match '^/mirror\.json$' -and (Test-Path $Mirror)) { Write-File $res $Mirror 'application/json; charset=utf-8'; continue }

      # DIAG
      if ($path -eq '/diag') {
        $exists = @{
          store    = Test-Path (Join-Path $Modules 'Osirisborn.Store.psm1')
          xp       = Test-Path (Join-Path $Modules 'Osirisborn.XP.psm1')
          missions = Test-Path (Join-Path $Modules 'Osirisborn.Missions.psm1')
        }
        $visible = Get-Command Add-OsMission,Get-OsMissions,Complete-OsMission,Add-OsXP,Get-OsXP -ErrorAction SilentlyContinue |
                   Select-Object Name,ModuleName
        Write-Json $res @{ mode='module'; modulesPath=$Modules; exists=$exists; visible=$visible }; continue
      }

      # XP
      if ($path -eq '/xp.json') {
        $days = 30; try { if ($req.QueryString['days']) { $days = [int]$req.QueryString['days'] } } catch {}
        Write-Json $res (Summarize-XP -Days $days); continue
      }
      if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $delta=[int]$b.delta; $reason="$($b.reason)"
        if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
        if (-not $reason) { $reason = 'Manual XP' }
        if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
          Add-OsXP -Amount $delta -Reason $reason | Out-Null
        } else {
          Initialize-OsStore
          $s = Get-OsStore
          $s.user.xp = [int]$s.user.xp + $delta
          Save-OsStore $s
        }
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # Missions
      if ($path -eq '/api/missions' -and $method -eq 'GET') {
        Initialize-OsStore
        $items = Get-OsMissions | ForEach-Object {
          [pscustomobject]@{ id="$($_.Id)"; title="$($_.Title)"; xp=[int]$_.XP; status="$($_.Status)" }
        }
        Write-Json $res @{ items = @($items) }; continue
      }
      if ($path -eq '/api/mission/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"; $title="$($b.title)"; $xp=[int]$b.xp
        if (-not $id)    { Write-Json $res @{ error="Missing id" } 400; continue }
        if (-not $title) { $title='New Mission' }
        Add-OsMission -Id $id -XP $xp -Title $title | Out-Null
        Write-Json $res @{ ok=$true; id=$id }; continue
      }
      if ($path -eq '/api/mission/complete' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"
        if (-not $id) { Write-Json $res @{ error='Missing id' } 400; continue }
        $null = Complete-OsMission -Id $id
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; id=$id; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # 404
      Write-Json $res @{ error = "Not found: $path" } 404
    } catch {
      try { Write-Json $ctx.Response @{ error = $_.Exception.Message } } catch {}
    }
  }
} finally { try { $listener.Stop(); $listener.Close() } catch {} }

_req.InputStream, [Text.Encoding]::UTF8)).ReadToEnd()
    $o = $null; try { $o = $body | ConvertFrom-Json } catch {}
    $delta = [int]($o.delta); if (-not $delta) { $delta = 0 }
    $reason = [string]$o.reason
    $now = Get-Date

    $wrap = _bpReadStore
    $s = $wrap.store
    $evt = [PSCustomObject]@{ ts = $now.ToString("o"); delta = $delta; reason = $reason }
    $s.xp.events = @($s.xp.events + $evt)
    _bpSaveStore $s

    _bpWriteJson @{ ok=$true; awarded=$delta; ts=$evt.ts; events=@($s.xp.events).Count }
    continue
  } catch {
    _bpWriteJson @{ error="xp-add-failed" } 500
    continue
  }
}

# GET /xp.json?days=N  -- daily buckets + summary (shape matches current array [true, {...}])
if (#requires -Version 7.0

# ==== BEGIN BP STORE FALLBACK (Initialize/Get/Save-OsStore) ====
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root = $root; dataDir = $dataDir; storePath = $storePath }
}

if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      $p = _bpStorePaths
      if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
      if (-not (Test-Path $p.storePath)) {
        '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}

if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $p = _bpStorePaths
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $p.storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $p.storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json
    } catch {
      $obj = ConvertFrom-Json '{"xp":{"events":[]}}'
      $obj | ConvertTo-Json -Depth 50 | Set-Content -Path $p.storePath -Encoding UTF8
    }
    if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $obj
  }
}

if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $p = _bpStorePaths
    Initialize-OsStore | Out-Null
    try {
      $json = $Store | ConvertTo-Json -Depth 50
      $json | Set-Content -Path $p.storePath -Encoding UTF8
      return $true
    } catch { return $false }
  }
}
# ==== END BP STORE FALLBACK ====

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'
$Mirror  = Join-Path $Www 'mirror.json'

. (Join-Path $Modules 'Osirisborn.Store.psm1')
. (Join-Path $Modules 'Osirisborn.XP.psm1')
. (Join-Path $Modules 'Osirisborn.Missions.psm1')

function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $res.StatusCode = $status
    $json  = ($obj | ConvertTo-Json -Depth 6)
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 6 } catch { return @{} }
}
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  return @{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  }
}

# Use 7780 to avoid any 7777 conflicts
$Port = 7780

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
# OSB: disabled opener -> Start-Process "http://localhost:$Port/"
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath
# ==== BEGIN LESSONS API GUARD (LESS-003) ====
# Defensive helpers
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 12 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpDataDir {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  [IO.Path]::GetFullPath((Join-Path $root "..\data"))
}
function _bpReadBody {
  $req = _bpGetReq
  if (-not $req) { return $null }
  try {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $s  = $sr.ReadToEnd(); $sr.Close(); return $s
  } catch { return $null }
}

# Short-circuit based on path (and method for POST)
$__p = $path
$__m = ( _bpGetReq )?.HttpMethod

if ($__p -eq "/api/lessons/summary") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    $tracks = @()

    if (Test-Path $currPath) {
      $curr = Get-Content $currPath -Raw | ConvertFrom-Json
      $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }

      foreach ($t in $curr.tracks) {
        $lessonsCount = 0
        foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
        $completed = 0
        if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
          $completed = @($prog.$($t.id).completedLessons).Count
        }
        $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
        $tracks += [PSCustomObject]@{
          id        = $t.id
          title     = $t.title
          lessons   = $lessonsCount
          completed = $completed
          progress  = $progress
        }
      }
    }

    _bpWriteJson ([PSCustomObject]@{ totalTracks = @($tracks).Count; tracks = $tracks })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-summary-failed" } 500
    continue
  }
}
elseif ($__p -like "/api/lessons/track/*") {
  try {
    $tid = $__p.Substring("/api/lessons/track/".Length)
    if ([string]::IsNullOrWhiteSpace($tid)) { _bpWriteJson @{ error="missing-track-id" } 400; continue }

    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    $completedSet = @{}
    if ($prog -and ($prog.PSObject.Properties.Name -contains $tid)) {
      foreach ($lid in $prog.$tid.completedLessons) { $completedSet[$lid] = $true }
    }

    $total = 0; $done = 0
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        $total++
        if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true -Force }
        else                                   {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
      }
    }
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }

    _bpWriteJson ([PSCustomObject]@{
      id       = $track.id
      title    = $track.title
      progress = $progress
      modules  = $track.modules
      totals   = @{ lessons = $total; completed = $done }
    })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-track-failed" } 500
    continue
  }
}
elseif ($__m -eq "POST" -and $__p -eq "/api/lessons/complete") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $body = _bpReadBody
    if (-not $body) { _bpWriteJson @{ error="missing-body" } 400; continue }
    try { $obj = $body | ConvertFrom-Json } catch { _bpWriteJson @{ error="bad-json" } 400; continue }

    $tid = $obj.trackId; $lid = $obj.lessonId
    if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) {
      _bpWriteJson @{ error="missing-params" } 400; continue
    }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    # Locate lesson and XP
    $foundLesson = $null
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        if ($l.id -eq $lid) { $foundLesson = $l; break }
      }
      if ($foundLesson) { break }
    }
    if (-not $foundLesson) { _bpWriteJson @{ error="lesson-not-found" } 404; continue }

    $xp = $foundLesson.xp
    if (-not $xp) { $xp = $track.xpPerLesson }
    if (-not $xp) { $xp = 10 }

    # Read or init progress
    if (Test-Path $progPath) { $prog = Get-Content $progPath -Raw | ConvertFrom-Json } else { $prog = @{} | ConvertTo-Json | ConvertFrom-Json }
    if (-not ($prog.PSObject.Properties.Name -contains $tid)) {
      $prog | Add-Member -NotePropertyName $tid -NotePropertyValue ( [PSCustomObject]@{ completedLessons = @() } ) -Force
    }

    $list = @($prog.$tid.completedLessons)
    $already = $false
    foreach ($x in $list) { if ($x -eq $lid) { $already = $true; break } }

    if ($already) {
      # compute current totals/progress
      $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
      $completed = @($prog.$tid.completedLessons).Count
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      _bpWriteJson @{ status="exists"; awarded=0; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
      continue
    }

    # Append, save
    $newList = @($prog.$tid.completedLessons + $lid)
    $prog.$tid.completedLessons = $newList
    # Persist to file
    $jsonOut = $prog | ConvertTo-Json -Depth 12
    $jsonOut | Set-Content -Path $progPath -Encoding UTF8

    # compute new totals/progress
    $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
    $completed = @($prog.$tid.completedLessons).Count
    $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }

    _bpWriteJson @{ status="ok"; awarded=$xp; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-complete-failed" } 500
    continue
  }
}
# ==== END LESSONS API GUARD (LESS-003) ====
      $method = $req.HttpMethod.ToUpperInvariant()

      # Static
# ---- XP: add (module-first, with safe fallback)
if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
  $b = Read-Body $req
  $delta  = [int]$b.delta
  $reason = [string]$b.reason
  if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
  if ([string]::IsNullOrWhiteSpace($reason)) { $reason = 'Manual XP' }

  $usedModules = $false
  try {
    if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
      Add-OsXP -Amount $delta -Reason $reason | Out-Null
      $usedModules = $true
    }
  } catch {}

  if (-not $usedModules) {
    # ---- minimal self-contained fallback (no Initialize-OsStore dependency)
    if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
    $storePath = Join-Path $DataDir 'store.plasma'
    if (!(Test-Path $storePath)) {
      $default = [pscustomobject]@{
        user = [pscustomobject]@{ xp=0; rank='Initiate'; alias='Osirisborn'; progressPct=0 }
        missions = [pscustomobject]@{ catalog=@{}; completed=@() }
        meta = [pscustomobject]@{ xpLog=@() }
        settings = [pscustomobject]@{ dailyGoal=300; notify=$true }
      }
      Set-Content -Path $storePath -Value ($default | ConvertTo-Json -Depth 6) -Encoding UTF8
    }
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $s.user.xp = [int]($s.user.xp) + $delta

    # rank & progress (same thresholds as CLI)
    $threshold = @{
      'Initiate'=0; 'Ghost'=200; 'Signal Diver'=600; 'Network Phantom'=1200; 'Redline Operative'=2000;
      'Shadow Architect'=3000; 'Spectral Engineer'=4500; 'Elite'=6500; 'Voidbreaker'=9000; 'God Tier: Osirisborn'=12000
    }
    $ranks = @('Initiate','Ghost','Signal Diver','Network Phantom','Redline Operative','Shadow Architect','Spectral Engineer','Elite','Voidbreaker','God Tier: Osirisborn')
    foreach($r in $ranks){ if ($s.user.xp -ge $threshold[$r]) { $s.user.rank=$r } }
    $curr = $threshold[$s.user.rank]
    $next = $threshold[$ranks[[Math]::Min($ranks.IndexOf($s.user.rank)+1, $ranks.Count-1)]]
    $span = [Math]::Max(1, $next-$curr)
    $s.user.progressPct = [int][Math]::Clamp(100*($s.user.xp-$curr)/$span,0,100)

    # log entry
    if (-not $s.meta) { $s | Add-Member meta ([pscustomobject]@{}) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member xpLog @() -Force }
    $s.meta.xpLog = @($s.meta.xpLog + [pscustomobject]@{
      at=(Get-Date).ToString('o'); delta=$delta; reason=$reason; total=[int]$s.user.xp; rank=$s.user.rank
    })

    Set-Content $storePath ($s | ConvertTo-Json -Depth 6) -Encoding UTF8
  }

  # respond with current xp/rank
  $xp = $null
  if (Get-Command Get-OsXP -ErrorAction SilentlyContinue) { $xp = Get-OsXP }
  if (-not $xp) {
    $storePath = Join-Path $DataDir 'store.plasma'
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $xp = [pscustomobject]@{ Rank=$s.user.rank; XP=[int]$s.user.xp; ProgressPct=[int]($s.user.progressPct) }
  }
  Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=[int]($xp.ProgressPct) }; continue
}
      
if     ($path -eq '/' -or $path -match '^/index\.html$') { Write-File $res (Join-Path $Www 'index.html') 'text/html; charset=utf-8'; continue }
      elseif ($path -match '^/client\.js$')                    { Write-File $res (Join-Path $Www 'client.js') 'application/javascript; charset=utf-8'; continue }
      elseif ($path -match '^/mirror\.json$' -and (Test-Path $Mirror)) { Write-File $res $Mirror 'application/json; charset=utf-8'; continue }

      # DIAG
      if ($path -eq '/diag') {
        $exists = @{
          store    = Test-Path (Join-Path $Modules 'Osirisborn.Store.psm1')
          xp       = Test-Path (Join-Path $Modules 'Osirisborn.XP.psm1')
          missions = Test-Path (Join-Path $Modules 'Osirisborn.Missions.psm1')
        }
        $visible = Get-Command Add-OsMission,Get-OsMissions,Complete-OsMission,Add-OsXP,Get-OsXP -ErrorAction SilentlyContinue |
                   Select-Object Name,ModuleName
        Write-Json $res @{ mode='module'; modulesPath=$Modules; exists=$exists; visible=$visible }; continue
      }

      # XP
      if ($path -eq '/xp.json') {
        $days = 30; try { if ($req.QueryString['days']) { $days = [int]$req.QueryString['days'] } } catch {}
        Write-Json $res (Summarize-XP -Days $days); continue
      }
      if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $delta=[int]$b.delta; $reason="$($b.reason)"
        if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
        if (-not $reason) { $reason = 'Manual XP' }
        if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
          Add-OsXP -Amount $delta -Reason $reason | Out-Null
        } else {
          Initialize-OsStore
          $s = Get-OsStore
          $s.user.xp = [int]$s.user.xp + $delta
          Save-OsStore $s
        }
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # Missions
      if ($path -eq '/api/missions' -and $method -eq 'GET') {
        Initialize-OsStore
        $items = Get-OsMissions | ForEach-Object {
          [pscustomobject]@{ id="$($_.Id)"; title="$($_.Title)"; xp=[int]$_.XP; status="$($_.Status)" }
        }
        Write-Json $res @{ items = @($items) }; continue
      }
      if ($path -eq '/api/mission/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"; $title="$($b.title)"; $xp=[int]$b.xp
        if (-not $id)    { Write-Json $res @{ error="Missing id" } 400; continue }
        if (-not $title) { $title='New Mission' }
        Add-OsMission -Id $id -XP $xp -Title $title | Out-Null
        Write-Json $res @{ ok=$true; id=$id }; continue
      }
      if ($path -eq '/api/mission/complete' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"
        if (-not $id) { Write-Json $res @{ error='Missing id' } 400; continue }
        $null = Complete-OsMission -Id $id
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; id=$id; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # 404
      Write-Json $res @{ error = "Not found: $path" } 404
    } catch {
      try { Write-Json $ctx.Response @{ error = $_.Exception.Message } } catch {}
    }
  }
} finally { try { $listener.Stop(); $listener.Close() } catch {} }

_p -eq "/xp.json") {
  try {
    $days = 7
    try {
      $q = #requires -Version 7.0

# ==== BEGIN BP STORE FALLBACK (Initialize/Get/Save-OsStore) ====
function _bpStorePaths {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  $dataDir   = Join-Path $root "..\data"
  $storePath = Join-Path $dataDir "store.plasma"
  [PSCustomObject]@{ root = $root; dataDir = $dataDir; storePath = $storePath }
}

if (-not (Get-Command Initialize-OsStore -ErrorAction SilentlyContinue)) {
  function Initialize-OsStore {
    try {
      $p = _bpStorePaths
      if (-not (Test-Path $p.dataDir)) { New-Item -ItemType Directory -Path $p.dataDir -Force | Out-Null }
      if (-not (Test-Path $p.storePath)) {
        '{"xp":{"events":[]}}' | Set-Content -Path $p.storePath -Encoding UTF8
      }
      return $true
    } catch { return $false }
  }
}

if (-not (Get-Command Get-OsStore -ErrorAction SilentlyContinue)) {
  function Get-OsStore {
    param([switch]$Ensure)
    $p = _bpStorePaths
    if ($Ensure) { Initialize-OsStore | Out-Null }
    if (-not (Test-Path $p.storePath)) { Initialize-OsStore | Out-Null }
    try {
      $raw = Get-Content $p.storePath -Raw -ErrorAction Stop
      $obj = $raw | ConvertFrom-Json
    } catch {
      $obj = ConvertFrom-Json '{"xp":{"events":[]}}'
      $obj | ConvertTo-Json -Depth 50 | Set-Content -Path $p.storePath -Encoding UTF8
    }
    if (-not $obj.xp) { $obj | Add-Member -NotePropertyName xp -NotePropertyValue ([PSCustomObject]@{ events=@() }) -Force }
    if (-not $obj.xp.events) { $obj.xp | Add-Member -NotePropertyName events -NotePropertyValue @() -Force }
    return $obj
  }
}

if (-not (Get-Command Save-OsStore -ErrorAction SilentlyContinue)) {
  function Save-OsStore {
    param([Parameter(Mandatory=$true)]$Store)
    $p = _bpStorePaths
    Initialize-OsStore | Out-Null
    try {
      $json = $Store | ConvertTo-Json -Depth 50
      $json | Set-Content -Path $p.storePath -Encoding UTF8
      return $true
    } catch { return $false }
  }
}
# ==== END BP STORE FALLBACK ====

[Console]::OutputEncoding = [Text.Encoding]::UTF8

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Root    = Split-Path $ScriptRoot -Parent
$Modules = Join-Path $ScriptRoot 'modules'
$Www     = Join-Path $Root 'www'
$DataDir = Join-Path $Root 'data'
$Mirror  = Join-Path $Www 'mirror.json'

. (Join-Path $Modules 'Osirisborn.Store.psm1')
. (Join-Path $Modules 'Osirisborn.XP.psm1')
. (Join-Path $Modules 'Osirisborn.Missions.psm1')

function Write-Json([System.Net.HttpListenerResponse]$res, $obj, [int]$status=200) {
  try {
    $res.StatusCode = $status
    $json  = ($obj | ConvertTo-Json -Depth 6)
    $bytes = [Text.Encoding]::UTF8.GetBytes($json)
    $res.ContentType = 'application/json; charset=utf-8'
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Write-File([System.Net.HttpListenerResponse]$res, [string]$path, [string]$contentType) {
  try {
    $bytes = [IO.File]::ReadAllBytes($path)
    $res.StatusCode = 200
    $res.ContentType = $contentType
    $res.OutputStream.Write($bytes,0,$bytes.Length)
  } finally { $res.Close() }
}
function Read-Body([System.Net.HttpListenerRequest]$req) {
  $sr   = New-Object IO.StreamReader($req.InputStream, $req.ContentEncoding)
  $text = $sr.ReadToEnd(); $sr.Close()
  if ([string]::IsNullOrWhiteSpace($text)) { return @{} }
  try { return $text | ConvertFrom-Json -Depth 6 } catch { return @{} }
}
function Summarize-XP([int]$Days=30) {
  Initialize-OsStore
  $s = Get-OsStore
  $end = (Get-Date).Date
  $start = $end.AddDays(-[Math]::Max(0, $Days-1))
  $buckets = @{}
  for ($d=$start; $d -le $end; $d=$d.AddDays(1)) { $buckets[$d.ToString('yyyy-MM-dd')] = 0 }
  $log = if ($s.meta -and $s.meta.xpLog) { $s.meta.xpLog } else { @() }
  foreach ($e in $log) {
    try {
      $dt = [DateTime]::Parse($e.at)
      $key = $dt.ToString('yyyy-MM-dd')
      if ($buckets.ContainsKey($key)) { $buckets[$key] += [int]$e.delta }
    } catch {}
  }
  $series = @(); $cum = 0
  foreach ($kv in ($buckets.GetEnumerator() | Sort-Object Name)) {
    $cum += [int]$kv.Value
    $series += [pscustomobject]@{ date=$kv.Key; xp=[int]$kv.Value; cumulative=$cum }
  }
  $nowKey  = (Get-Date).ToString('yyyy-MM-dd')
  $xpToday = if ($buckets.ContainsKey($nowKey)) { [int]$buckets[$nowKey] } else { 0 }
  $goal    = if ($s.settings -and $s.settings.dailyGoal) { [int]$s.settings.dailyGoal } else { 300 }
  $remain  = [Math]::Max(0, $goal - $xpToday)
  $o = Get-OsXP
  return @{
    days   = $Days
    series = $series
    summary = @{
      xpToday     = $xpToday
      dailyGoal   = $goal
      remaining   = $remain
      rank        = $o.Rank
      xp          = $o.XP
      progressPct = $o.ProgressPct
    }
  }
}

# Use 7780 to avoid any 7777 conflicts
$Port = 7780

$listener = [System.Net.HttpListener]::new()
$listener.Prefixes.Add("http://localhost:$Port/")
$listener.Prefixes.Add("http://+:$Port/")
$listener.Start()
# OSB: disabled opener -> Start-Process "http://localhost:$Port/"
Write-Host "Osirisborn server running → http://localhost:$Port/  (Ctrl+C to stop)"

try {
  while ($listener.IsListening) {
    $ctx = $listener.GetContext()
    try {
      $req = $ctx.Request; $res = $ctx.Response
      $path = $req.Url.AbsolutePath
# ==== BEGIN LESSONS API GUARD (LESS-003) ====
# Defensive helpers
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 12 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpDataDir {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  [IO.Path]::GetFullPath((Join-Path $root "..\data"))
}
function _bpReadBody {
  $req = _bpGetReq
  if (-not $req) { return $null }
  try {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $s  = $sr.ReadToEnd(); $sr.Close(); return $s
  } catch { return $null }
}

# Short-circuit based on path (and method for POST)
$__p = $path
$__m = ( _bpGetReq )?.HttpMethod

if ($__p -eq "/api/lessons/summary") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    $tracks = @()

    if (Test-Path $currPath) {
      $curr = Get-Content $currPath -Raw | ConvertFrom-Json
      $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }

      foreach ($t in $curr.tracks) {
        $lessonsCount = 0
        foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
        $completed = 0
        if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
          $completed = @($prog.$($t.id).completedLessons).Count
        }
        $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
        $tracks += [PSCustomObject]@{
          id        = $t.id
          title     = $t.title
          lessons   = $lessonsCount
          completed = $completed
          progress  = $progress
        }
      }
    }

    _bpWriteJson ([PSCustomObject]@{ totalTracks = @($tracks).Count; tracks = $tracks })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-summary-failed" } 500
    continue
  }
}
elseif ($__p -like "/api/lessons/track/*") {
  try {
    $tid = $__p.Substring("/api/lessons/track/".Length)
    if ([string]::IsNullOrWhiteSpace($tid)) { _bpWriteJson @{ error="missing-track-id" } 400; continue }

    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    $completedSet = @{}
    if ($prog -and ($prog.PSObject.Properties.Name -contains $tid)) {
      foreach ($lid in $prog.$tid.completedLessons) { $completedSet[$lid] = $true }
    }

    $total = 0; $done = 0
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        $total++
        if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true -Force }
        else                                   {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
      }
    }
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }

    _bpWriteJson ([PSCustomObject]@{
      id       = $track.id
      title    = $track.title
      progress = $progress
      modules  = $track.modules
      totals   = @{ lessons = $total; completed = $done }
    })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-track-failed" } 500
    continue
  }
}
elseif ($__m -eq "POST" -and $__p -eq "/api/lessons/complete") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $body = _bpReadBody
    if (-not $body) { _bpWriteJson @{ error="missing-body" } 400; continue }
    try { $obj = $body | ConvertFrom-Json } catch { _bpWriteJson @{ error="bad-json" } 400; continue }

    $tid = $obj.trackId; $lid = $obj.lessonId
    if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) {
      _bpWriteJson @{ error="missing-params" } 400; continue
    }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    # Locate lesson and XP
    $foundLesson = $null
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        if ($l.id -eq $lid) { $foundLesson = $l; break }
      }
      if ($foundLesson) { break }
    }
    if (-not $foundLesson) { _bpWriteJson @{ error="lesson-not-found" } 404; continue }

    $xp = $foundLesson.xp
    if (-not $xp) { $xp = $track.xpPerLesson }
    if (-not $xp) { $xp = 10 }

    # Read or init progress
    if (Test-Path $progPath) { $prog = Get-Content $progPath -Raw | ConvertFrom-Json } else { $prog = @{} | ConvertTo-Json | ConvertFrom-Json }
    if (-not ($prog.PSObject.Properties.Name -contains $tid)) {
      $prog | Add-Member -NotePropertyName $tid -NotePropertyValue ( [PSCustomObject]@{ completedLessons = @() } ) -Force
    }

    $list = @($prog.$tid.completedLessons)
    $already = $false
    foreach ($x in $list) { if ($x -eq $lid) { $already = $true; break } }

    if ($already) {
      # compute current totals/progress
      $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
      $completed = @($prog.$tid.completedLessons).Count
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      _bpWriteJson @{ status="exists"; awarded=0; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
      continue
    }

    # Append, save
    $newList = @($prog.$tid.completedLessons + $lid)
    $prog.$tid.completedLessons = $newList
    # Persist to file
    $jsonOut = $prog | ConvertTo-Json -Depth 12
    $jsonOut | Set-Content -Path $progPath -Encoding UTF8

    # compute new totals/progress
    $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
    $completed = @($prog.$tid.completedLessons).Count
    $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }

    _bpWriteJson @{ status="ok"; awarded=$xp; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-complete-failed" } 500
    continue
  }
}
# ==== END LESSONS API GUARD (LESS-003) ====
      $method = $req.HttpMethod.ToUpperInvariant()

      # Static
# ---- XP: add (module-first, with safe fallback)
if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
  $b = Read-Body $req
  $delta  = [int]$b.delta
  $reason = [string]$b.reason
  if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
  if ([string]::IsNullOrWhiteSpace($reason)) { $reason = 'Manual XP' }

  $usedModules = $false
  try {
    if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
      Add-OsXP -Amount $delta -Reason $reason | Out-Null
      $usedModules = $true
    }
  } catch {}

  if (-not $usedModules) {
    # ---- minimal self-contained fallback (no Initialize-OsStore dependency)
    if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
    $storePath = Join-Path $DataDir 'store.plasma'
    if (!(Test-Path $storePath)) {
      $default = [pscustomobject]@{
        user = [pscustomobject]@{ xp=0; rank='Initiate'; alias='Osirisborn'; progressPct=0 }
        missions = [pscustomobject]@{ catalog=@{}; completed=@() }
        meta = [pscustomobject]@{ xpLog=@() }
        settings = [pscustomobject]@{ dailyGoal=300; notify=$true }
      }
      Set-Content -Path $storePath -Value ($default | ConvertTo-Json -Depth 6) -Encoding UTF8
    }
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $s.user.xp = [int]($s.user.xp) + $delta

    # rank & progress (same thresholds as CLI)
    $threshold = @{
      'Initiate'=0; 'Ghost'=200; 'Signal Diver'=600; 'Network Phantom'=1200; 'Redline Operative'=2000;
      'Shadow Architect'=3000; 'Spectral Engineer'=4500; 'Elite'=6500; 'Voidbreaker'=9000; 'God Tier: Osirisborn'=12000
    }
    $ranks = @('Initiate','Ghost','Signal Diver','Network Phantom','Redline Operative','Shadow Architect','Spectral Engineer','Elite','Voidbreaker','God Tier: Osirisborn')
    foreach($r in $ranks){ if ($s.user.xp -ge $threshold[$r]) { $s.user.rank=$r } }
    $curr = $threshold[$s.user.rank]
    $next = $threshold[$ranks[[Math]::Min($ranks.IndexOf($s.user.rank)+1, $ranks.Count-1)]]
    $span = [Math]::Max(1, $next-$curr)
    $s.user.progressPct = [int][Math]::Clamp(100*($s.user.xp-$curr)/$span,0,100)

    # log entry
    if (-not $s.meta) { $s | Add-Member meta ([pscustomobject]@{}) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member xpLog @() -Force }
    $s.meta.xpLog = @($s.meta.xpLog + [pscustomobject]@{
      at=(Get-Date).ToString('o'); delta=$delta; reason=$reason; total=[int]$s.user.xp; rank=$s.user.rank
    })

    Set-Content $storePath ($s | ConvertTo-Json -Depth 6) -Encoding UTF8
  }

  # respond with current xp/rank
  $xp = $null
  if (Get-Command Get-OsXP -ErrorAction SilentlyContinue) { $xp = Get-OsXP }
  if (-not $xp) {
    $storePath = Join-Path $DataDir 'store.plasma'
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $xp = [pscustomobject]@{ Rank=$s.user.rank; XP=[int]$s.user.xp; ProgressPct=[int]($s.user.progressPct) }
  }
  Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=[int]($xp.ProgressPct) }; continue
}
      
if     ($path -eq '/' -or $path -match '^/index\.html$') { Write-File $res (Join-Path $Www 'index.html') 'text/html; charset=utf-8'; continue }
      elseif ($path -match '^/client\.js$')                    { Write-File $res (Join-Path $Www 'client.js') 'application/javascript; charset=utf-8'; continue }
      elseif ($path -match '^/mirror\.json$' -and (Test-Path $Mirror)) { Write-File $res $Mirror 'application/json; charset=utf-8'; continue }

      # DIAG
      if ($path -eq '/diag') {
        $exists = @{
          store    = Test-Path (Join-Path $Modules 'Osirisborn.Store.psm1')
          xp       = Test-Path (Join-Path $Modules 'Osirisborn.XP.psm1')
          missions = Test-Path (Join-Path $Modules 'Osirisborn.Missions.psm1')
        }
        $visible = Get-Command Add-OsMission,Get-OsMissions,Complete-OsMission,Add-OsXP,Get-OsXP -ErrorAction SilentlyContinue |
                   Select-Object Name,ModuleName
        Write-Json $res @{ mode='module'; modulesPath=$Modules; exists=$exists; visible=$visible }; continue
      }

      # XP
      if ($path -eq '/xp.json') {
        $days = 30; try { if ($req.QueryString['days']) { $days = [int]$req.QueryString['days'] } } catch {}
        Write-Json $res (Summarize-XP -Days $days); continue
      }
      if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $delta=[int]$b.delta; $reason="$($b.reason)"
        if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
        if (-not $reason) { $reason = 'Manual XP' }
        if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
          Add-OsXP -Amount $delta -Reason $reason | Out-Null
        } else {
          Initialize-OsStore
          $s = Get-OsStore
          $s.user.xp = [int]$s.user.xp + $delta
          Save-OsStore $s
        }
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # Missions
      if ($path -eq '/api/missions' -and $method -eq 'GET') {
        Initialize-OsStore
        $items = Get-OsMissions | ForEach-Object {
          [pscustomobject]@{ id="$($_.Id)"; title="$($_.Title)"; xp=[int]$_.XP; status="$($_.Status)" }
        }
        Write-Json $res @{ items = @($items) }; continue
      }
      if ($path -eq '/api/mission/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"; $title="$($b.title)"; $xp=[int]$b.xp
        if (-not $id)    { Write-Json $res @{ error="Missing id" } 400; continue }
        if (-not $title) { $title='New Mission' }
        Add-OsMission -Id $id -XP $xp -Title $title | Out-Null
        Write-Json $res @{ ok=$true; id=$id }; continue
      }
      if ($path -eq '/api/mission/complete' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"
        if (-not $id) { Write-Json $res @{ error='Missing id' } 400; continue }
        $null = Complete-OsMission -Id $id
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; id=$id; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # 404
      Write-Json $res @{ error = "Not found: $path" } 404
    } catch {
      try { Write-Json $ctx.Response @{ error = $_.Exception.Message } } catch {}
    }
  }
} finally { try { $listener.Stop(); $listener.Close() } catch {} }

_req.Url.Query
      if ($q -match 'days=(\d{1,3})') { $days = [int]$Matches[1] }
      if ($days -lt 1) { $days = 1 }
      if ($days -gt 365) { $days = 365 }
    } catch {}

    $wrap = _bpReadStore
    $events = @($wrap.store.xp.events)
    $today = (Get-Date).Date

    $series = @(); $cum = 0; $xpToday = 0
    for ($i=$days-1; $i -ge 0; $i--) {
      $d = $today.AddDays(-$i)
      $sum = 0
      foreach ($e in $events) {
        try {
          $t = [DateTime]::Parse($e.ts, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::RoundtripKind)
          if ($t.Date -eq $d) { $sum += [int]$e.delta }
        } catch {}
      }
      $cum += $sum
      if ($d -eq $today) { $xpToday = $sum }
      $series += [PSCustomObject]@{ date = $d.ToString("yyyy-MM-dd"); xp = $sum; cumulative = $cum }
    }

    $dailyGoal = 300
    $summary = [PSCustomObject]@{
      dailyGoal   = $dailyGoal
      xp          = $cum
      xpToday     = $xpToday
      progressPct = if ($dailyGoal -gt 0) { [Math]::Round([Math]::Min(100, ($xpToday*100.0)/$dailyGoal)) } else { $null }
      remaining   = if ($dailyGoal -gt 0) { [Math]::Max(0, $dailyGoal - $xpToday) } else { $null }
      rank        = $null
    }

    _bpWriteJson @($true, @{ series=$series; days=$days; summary=$summary })
    continue
  } catch {
    _bpWriteJson @{ error="xp-json-failed" } 500
    continue
  }
}
# ==== END XP SAFE GUARD (LESS-003) ====
# ==== BEGIN LESSONS API GUARD (LESS-003) ====
# Defensive helpers
function _bpGetReq {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Request) { return $v.Value.Request } } catch {} }
  }
  foreach ($n in 'Request','request','req') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpGetRes {
  foreach ($n in 'context','ctx','httpContext','httpCtx') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v) { try { if ($v.Value -and $v.Value.Response) { return $v.Value.Response } } catch {} }
  }
  foreach ($n in 'Response','response','res') {
    $v = Get-Variable -Name $n -ErrorAction SilentlyContinue
    if ($v -and $v.Value) { return $v.Value }
  }
  return $null
}
function _bpSetProp($o,$name,$val){
  if ($null -ne $o -and ($o.PSObject.Properties.Name -contains $name)) {
    try { $o.$name = $val } catch {}
  }
}
function _bpWriteJson($obj, [int]$code = 200) {
  try { $json = $obj | ConvertTo-Json -Depth 12 } catch { $json = '{"error":"serialization"}' }
  $bytes = [Text.Encoding]::UTF8.GetBytes($json)
  $r = _bpGetRes
  _bpSetProp $r 'ContentType' 'application/json; charset=utf-8'
  _bpSetProp $r 'ContentLength64' $bytes.Length
  _bpSetProp $r 'StatusCode' $code
  try {
    if ($r -and $r.OutputStream) {
      $r.OutputStream.Write($bytes,0,$bytes.Length)
      $r.OutputStream.Close()
    } else {
      [Console]::Out.WriteLine([Text.Encoding]::UTF8.GetString($bytes))
    }
  } catch {}
}
function _bpDataDir {
  if ($PSScriptRoot) { $root = $PSScriptRoot } else { $root = Split-Path -Parent $PSCommandPath }
  [IO.Path]::GetFullPath((Join-Path $root "..\data"))
}
function _bpReadBody {
  $req = _bpGetReq
  if (-not $req) { return $null }
  try {
    $sr = New-Object IO.StreamReader($req.InputStream, [Text.Encoding]::UTF8)
    $s  = $sr.ReadToEnd(); $sr.Close(); return $s
  } catch { return $null }
}

# Short-circuit based on path (and method for POST)
$__p = $path
$__m = ( _bpGetReq )?.HttpMethod

if ($__p -eq "/api/lessons/summary") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    $tracks = @()

    if (Test-Path $currPath) {
      $curr = Get-Content $currPath -Raw | ConvertFrom-Json
      $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }

      foreach ($t in $curr.tracks) {
        $lessonsCount = 0
        foreach ($m in $t.modules) { $lessonsCount += @($m.lessons).Count }
        $completed = 0
        if ($prog -and ($prog.PSObject.Properties.Name -contains $t.id)) {
          $completed = @($prog.$($t.id).completedLessons).Count
        }
        $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
        $tracks += [PSCustomObject]@{
          id        = $t.id
          title     = $t.title
          lessons   = $lessonsCount
          completed = $completed
          progress  = $progress
        }
      }
    }

    _bpWriteJson ([PSCustomObject]@{ totalTracks = @($tracks).Count; tracks = $tracks })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-summary-failed" } 500
    continue
  }
}
elseif ($__p -like "/api/lessons/track/*") {
  try {
    $tid = $__p.Substring("/api/lessons/track/".Length)
    if ([string]::IsNullOrWhiteSpace($tid)) { _bpWriteJson @{ error="missing-track-id" } 400; continue }

    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    $prog = if (Test-Path $progPath) { Get-Content $progPath -Raw | ConvertFrom-Json } else { $null }
    $completedSet = @{}
    if ($prog -and ($prog.PSObject.Properties.Name -contains $tid)) {
      foreach ($lid in $prog.$tid.completedLessons) { $completedSet[$lid] = $true }
    }

    $total = 0; $done = 0
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        $total++
        if ($completedSet.ContainsKey($l.id)) { $done++; $l | Add-Member -NotePropertyName completed -NotePropertyValue $true -Force }
        else                                   {        $l | Add-Member -NotePropertyName completed -NotePropertyValue $false -Force }
      }
    }
    $progress = if ($total -gt 0) { [Math]::Round(($done*100.0)/$total) } else { 0 }

    _bpWriteJson ([PSCustomObject]@{
      id       = $track.id
      title    = $track.title
      progress = $progress
      modules  = $track.modules
      totals   = @{ lessons = $total; completed = $done }
    })
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-track-failed" } 500
    continue
  }
}
elseif ($__m -eq "POST" -and $__p -eq "/api/lessons/complete") {
  try {
    $dataDir = _bpDataDir
    $currPath = Join-Path $dataDir "curriculum.json"
    $progPath = Join-Path $dataDir "progress.lessons.json"
    if (!(Test-Path $currPath)) { _bpWriteJson @{ error="no-curriculum" } 404; continue }

    $body = _bpReadBody
    if (-not $body) { _bpWriteJson @{ error="missing-body" } 400; continue }
    try { $obj = $body | ConvertFrom-Json } catch { _bpWriteJson @{ error="bad-json" } 400; continue }

    $tid = $obj.trackId; $lid = $obj.lessonId
    if ([string]::IsNullOrWhiteSpace($tid) -or [string]::IsNullOrWhiteSpace($lid)) {
      _bpWriteJson @{ error="missing-params" } 400; continue
    }

    $curr = Get-Content $currPath -Raw | ConvertFrom-Json
    $track = $curr.tracks | Where-Object { $_.id -eq $tid }
    if (-not $track) { _bpWriteJson @{ error="track-not-found" } 404; continue }

    # Locate lesson and XP
    $foundLesson = $null
    foreach ($m in $track.modules) {
      foreach ($l in $m.lessons) {
        if ($l.id -eq $lid) { $foundLesson = $l; break }
      }
      if ($foundLesson) { break }
    }
    if (-not $foundLesson) { _bpWriteJson @{ error="lesson-not-found" } 404; continue }

    $xp = $foundLesson.xp
    if (-not $xp) { $xp = $track.xpPerLesson }
    if (-not $xp) { $xp = 10 }

    # Read or init progress
    if (Test-Path $progPath) { $prog = Get-Content $progPath -Raw | ConvertFrom-Json } else { $prog = @{} | ConvertTo-Json | ConvertFrom-Json }
    if (-not ($prog.PSObject.Properties.Name -contains $tid)) {
      $prog | Add-Member -NotePropertyName $tid -NotePropertyValue ( [PSCustomObject]@{ completedLessons = @() } ) -Force
    }

    $list = @($prog.$tid.completedLessons)
    $already = $false
    foreach ($x in $list) { if ($x -eq $lid) { $already = $true; break } }

    if ($already) {
      # compute current totals/progress
      $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
      $completed = @($prog.$tid.completedLessons).Count
      $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }
      _bpWriteJson @{ status="exists"; awarded=0; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
      continue
    }

    # Append, save
    $newList = @($prog.$tid.completedLessons + $lid)
    $prog.$tid.completedLessons = $newList
    # Persist to file
    $jsonOut = $prog | ConvertTo-Json -Depth 12
    $jsonOut | Set-Content -Path $progPath -Encoding UTF8

    # compute new totals/progress
    $lessonsCount = 0; foreach ($m in $track.modules){ $lessonsCount += @($m.lessons).Count }
    $completed = @($prog.$tid.completedLessons).Count
    $progress = if ($lessonsCount -gt 0) { [Math]::Round(($completed*100.0)/$lessonsCount) } else { 0 }

    _bpWriteJson @{ status="ok"; awarded=$xp; trackId=$tid; lessonId=$lid; progress=$progress; totals=@{ lessons=$lessonsCount; completed=$completed } }
    continue
  } catch {
    _bpWriteJson @{ error = "lessons-complete-failed" } 500
    continue
  }
}
# ==== END LESSONS API GUARD (LESS-003) ====
      $method = $req.HttpMethod.ToUpperInvariant()

      # Static
# ---- XP: add (module-first, with safe fallback)
if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
  $b = Read-Body $req
  $delta  = [int]$b.delta
  $reason = [string]$b.reason
  if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
  if ([string]::IsNullOrWhiteSpace($reason)) { $reason = 'Manual XP' }

  $usedModules = $false
  try {
    if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
      Add-OsXP -Amount $delta -Reason $reason | Out-Null
      $usedModules = $true
    }
  } catch {}

  if (-not $usedModules) {
    # ---- minimal self-contained fallback (no Initialize-OsStore dependency)
    if (!(Test-Path $DataDir)) { New-Item -ItemType Directory -Force -Path $DataDir | Out-Null }
    $storePath = Join-Path $DataDir 'store.plasma'
    if (!(Test-Path $storePath)) {
      $default = [pscustomobject]@{
        user = [pscustomobject]@{ xp=0; rank='Initiate'; alias='Osirisborn'; progressPct=0 }
        missions = [pscustomobject]@{ catalog=@{}; completed=@() }
        meta = [pscustomobject]@{ xpLog=@() }
        settings = [pscustomobject]@{ dailyGoal=300; notify=$true }
      }
      Set-Content -Path $storePath -Value ($default | ConvertTo-Json -Depth 6) -Encoding UTF8
    }
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $s.user.xp = [int]($s.user.xp) + $delta

    # rank & progress (same thresholds as CLI)
    $threshold = @{
      'Initiate'=0; 'Ghost'=200; 'Signal Diver'=600; 'Network Phantom'=1200; 'Redline Operative'=2000;
      'Shadow Architect'=3000; 'Spectral Engineer'=4500; 'Elite'=6500; 'Voidbreaker'=9000; 'God Tier: Osirisborn'=12000
    }
    $ranks = @('Initiate','Ghost','Signal Diver','Network Phantom','Redline Operative','Shadow Architect','Spectral Engineer','Elite','Voidbreaker','God Tier: Osirisborn')
    foreach($r in $ranks){ if ($s.user.xp -ge $threshold[$r]) { $s.user.rank=$r } }
    $curr = $threshold[$s.user.rank]
    $next = $threshold[$ranks[[Math]::Min($ranks.IndexOf($s.user.rank)+1, $ranks.Count-1)]]
    $span = [Math]::Max(1, $next-$curr)
    $s.user.progressPct = [int][Math]::Clamp(100*($s.user.xp-$curr)/$span,0,100)

    # log entry
    if (-not $s.meta) { $s | Add-Member meta ([pscustomobject]@{}) -Force }
    if (-not $s.meta.xpLog){ $s.meta | Add-Member xpLog @() -Force }
    $s.meta.xpLog = @($s.meta.xpLog + [pscustomobject]@{
      at=(Get-Date).ToString('o'); delta=$delta; reason=$reason; total=[int]$s.user.xp; rank=$s.user.rank
    })

    Set-Content $storePath ($s | ConvertTo-Json -Depth 6) -Encoding UTF8
  }

  # respond with current xp/rank
  $xp = $null
  if (Get-Command Get-OsXP -ErrorAction SilentlyContinue) { $xp = Get-OsXP }
  if (-not $xp) {
    $storePath = Join-Path $DataDir 'store.plasma'
    $s = Get-Content $storePath -Raw | ConvertFrom-Json
    $xp = [pscustomobject]@{ Rank=$s.user.rank; XP=[int]$s.user.xp; ProgressPct=[int]($s.user.progressPct) }
  }
  Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=[int]($xp.ProgressPct) }; continue
}
      
if     ($path -eq '/' -or $path -match '^/index\.html$') { Write-File $res (Join-Path $Www 'index.html') 'text/html; charset=utf-8'; continue }
      elseif ($path -match '^/client\.js$')                    { Write-File $res (Join-Path $Www 'client.js') 'application/javascript; charset=utf-8'; continue }
      elseif ($path -match '^/mirror\.json$' -and (Test-Path $Mirror)) { Write-File $res $Mirror 'application/json; charset=utf-8'; continue }

      # DIAG
      if ($path -eq '/diag') {
        $exists = @{
          store    = Test-Path (Join-Path $Modules 'Osirisborn.Store.psm1')
          xp       = Test-Path (Join-Path $Modules 'Osirisborn.XP.psm1')
          missions = Test-Path (Join-Path $Modules 'Osirisborn.Missions.psm1')
        }
        $visible = Get-Command Add-OsMission,Get-OsMissions,Complete-OsMission,Add-OsXP,Get-OsXP -ErrorAction SilentlyContinue |
                   Select-Object Name,ModuleName
        Write-Json $res @{ mode='module'; modulesPath=$Modules; exists=$exists; visible=$visible }; continue
      }

      # XP
      if ($path -eq '/xp.json') {
        $days = 30; try { if ($req.QueryString['days']) { $days = [int]$req.QueryString['days'] } } catch {}
        Write-Json $res (Summarize-XP -Days $days); continue
      }
      if ($path -eq '/api/xp/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $delta=[int]$b.delta; $reason="$($b.reason)"
        if (-not $delta) { Write-Json $res @{ error="delta must be non-zero" } 400; continue }
        if (-not $reason) { $reason = 'Manual XP' }
        if (Get-Command Add-OsXP -ErrorAction SilentlyContinue) {
          Add-OsXP -Amount $delta -Reason $reason | Out-Null
        } else {
          Initialize-OsStore
          $s = Get-OsStore
          $s.user.xp = [int]$s.user.xp + $delta
          Save-OsStore $s
        }
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # Missions
      if ($path -eq '/api/missions' -and $method -eq 'GET') {
        Initialize-OsStore
        $items = Get-OsMissions | ForEach-Object {
          [pscustomobject]@{ id="$($_.Id)"; title="$($_.Title)"; xp=[int]$_.XP; status="$($_.Status)" }
        }
        Write-Json $res @{ items = @($items) }; continue
      }
      if ($path -eq '/api/mission/add' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"; $title="$($b.title)"; $xp=[int]$b.xp
        if (-not $id)    { Write-Json $res @{ error="Missing id" } 400; continue }
        if (-not $title) { $title='New Mission' }
        Add-OsMission -Id $id -XP $xp -Title $title | Out-Null
        Write-Json $res @{ ok=$true; id=$id }; continue
      }
      if ($path -eq '/api/mission/complete' -and $method -eq 'POST') {
        $b = Read-Body $req; $id="$($b.id)"
        if (-not $id) { Write-Json $res @{ error='Missing id' } 400; continue }
        $null = Complete-OsMission -Id $id
        $xp = Get-OsXP
        Write-Json $res @{ ok=$true; id=$id; rank=$xp.Rank; xp=$xp.XP; progressPct=$xp.ProgressPct }; continue
      }

      # 404
      Write-Json $res @{ error = "Not found: $path" } 404
    } catch {
      try { Write-Json $ctx.Response @{ error = $_.Exception.Message } } catch {}
    }
  }
} finally { try { $listener.Stop(); $listener.Close() } catch {} }

