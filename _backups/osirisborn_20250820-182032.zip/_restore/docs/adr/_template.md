# ADR: <title>

- **Status**: proposed | accepted | superseded
- **Date**: YYYY-MM-DD

## Context
<What problem are we solving? What constraints exist?>

## Decision
<What is the decision and why?>

## Consequences
<Positive/negative outcomes, follow-ups, risks.>
