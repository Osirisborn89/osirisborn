See MASTER_BLUEPRINT.md → Anubis AI section. Modes: Mentor, Debugger, Hype, Zen. Offline/online. Persona-aware.
