Set-StrictMode -Version Latest

Describe "Portal assets (served)" {
  It "serves portal.css and sw-register.js as non-HTML" {
    $base = "http://127.0.0.1:7780"
    foreach ($p in "/portal.css","/js/sw-register.js") {
      $r = Invoke-WebRequest ($base + $p) -UseBasicParsing
      $r.StatusCode | Should -Be 200
      ($r.Content.TrimStart().StartsWith("<")) | Should -BeFalse
    }
  }
  It "serves favicon.ico and favicon.png" {
    $base = "http://127.0.0.1:7780"
    (Invoke-WebRequest ($base + "/favicon.ico") -UseBasicParsing).StatusCode | Should -Be 200
    (Invoke-WebRequest ($base + "/favicon.png") -UseBasicParsing).StatusCode | Should -Be 200
  }
}

Describe "Template portal structure & routes" {
  BeforeAll {
    $base = "http://127.0.0.1:7780"
    $idx  = Invoke-WebRequest "$base/index.html?bust=$(Get-Date -Format yyyyMMddHHmmss)" -UseBasicParsing
    Set-Variable -Name idx -Value $idx -Scope Script
    Set-Variable -Name html -Value $idx.Content -Scope Script
  }

  It "contains nav and app containers" {
    $script:html | Should -Match '<nav id="osb-nav"'
    $script:html | Should -Match '<main id="app"'
  }

  It "includes home and learn templates" {
    $script:html | Should -Match '<template id="tpl-home"'
    $script:html | Should -Match '<template id="tpl-learn"'
  }

  It "has the universal back toolbar function" {
    $script:html | Should -Match 'function toolbarFor\('
  }

  It "homepage exposes all 10 tile anchors" {
    foreach ($anchor in '#/learn','#/lounge','#/project','#/cyber','#/help','#/ai','#/identity','#/xp','#/career','#/lore') {
      ($script:html -like "*$anchor*") | Should -BeTrue
    }
  }

  It "learning hub exposes core 5 anchors" {
    foreach ($anchor in '#/learn/python','#/learn/js','#/learn/cpp','#/learn/cyber','#/learn/ctf') {
      ($script:html -like "*$anchor*") | Should -BeTrue
    }
  }

  It "has templates for each learning detail page" {
    foreach ($tpl in 'tpl-learn-python','tpl-learn-js','tpl-learn-cpp','tpl-learn-cyber','tpl-learn-ctf') {
      $script:html | Should -Match ('<template id="' + $tpl + '"')
    }
  }

  It "has route normaliser present (lessons→learn, unknown→home)" {
    $script:html | Should -Match 'ROUTE NORMALISER'
    $script:html | Should -Match 'lessons'
  }
}
