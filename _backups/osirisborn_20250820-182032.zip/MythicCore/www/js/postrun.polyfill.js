(function(){try{if(!window.postRun){window.postRun=function(fn){try{if(typeof fn==="function")fn();}catch(e){}};
console.log("[postrun.polyfill] ready");}}catch(e){}})();
