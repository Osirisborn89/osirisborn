(function(){
  function onRoute(){
    const h=(location.hash||"").replace(/\/+$/,"");
    if(h==="#/learn/coding"){ window.Lessons?.mount("#learn-root"); }
  }
  addEventListener("hashchange",()=>requestAnimationFrame(onRoute));
  if(document.readyState==="loading"){ addEventListener("DOMContentLoaded",()=>requestAnimationFrame(onRoute)); }
  else { requestAnimationFrame(onRoute); }
})();
