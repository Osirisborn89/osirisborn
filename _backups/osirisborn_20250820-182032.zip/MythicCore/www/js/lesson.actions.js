window.Lessons=(function(){
  async function fetchTracks(){
    const urls=['/api/lessons/tracks.json','/api/lessons/tracks'];
    for(const u of urls){
      try{ const r=await fetch(u,{headers:{'Accept':'application/json'}}); if(r.ok) return r.json(); }catch(_){}
    }
    // safe stub if API missing
    return {title:'Python Mastery',modules:[
      {title:'Foundations',lessons:['py-01-01','py-01-02','py-01-03']},
      {title:'Core Syntax',lessons:['py-02-01','py-02-02','py-02-03']}
    ]};
  }
  function card(track){
    const wrap=document.createElement('div');
    wrap.innerHTML=`
      <div class="card" style="margin-top:8px">
        <h2 style="margin:0 0 6px 0;">${track.title||'Curriculum'}</h2>
        ${(track.modules||[]).map(m=>`
          <section style="margin:10px 0;">
            <div style="font-weight:600;margin-bottom:4px;">${m.title}</div>
            <ul style="margin:0;padding-left:18px;">${(m.lessons||[]).map(id=>`<li>${id}</li>`).join('')}</ul>
          </section>`).join('')}
      </div>`;
    return wrap;
  }
  async function mount(sel){
    const host=document.querySelector(sel)||document.body;
    host.innerHTML='';
    const data=await fetchTracks();
    host.appendChild(card(data));
  }
  return { mount };
})();
