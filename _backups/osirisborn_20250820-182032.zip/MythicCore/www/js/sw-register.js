(()=>{ try{
  const url=new URL(location.href);
  const swOff=url.searchParams.get("sw")==="off";
  if(swOff){
    console.log("[SW] dev mode: service worker disabled");
    if("serviceWorker" in navigator){
      navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister()));
    }
    return;
  }
  if("serviceWorker" in navigator){
    window.addEventListener("load",()=>navigator.serviceWorker.register("/sw.js")
      .then(r=>console.log("[SW] registered ok; scope=", r.scope))
      .catch(e=>console.warn("[SW] registration failed", e)));
  }
}catch(e){ console.warn("[SW] script error", e); }})();
