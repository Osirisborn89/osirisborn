;(() => {
  console.log('LESS-016 portal booted');
  const byId = (id) => document.getElementById(id);

  function ensureNav() {
    const nav = byId('osb-nav');
    if (!nav) { console.warn('LESS-021 nav not found'); return; }
    nav.innerHTML = 
      <a href="#/home">Home</a>
      <a href="#/learn">Learning</a>
      <a href="#/lounge">Downtime Lounge</a>
      <a href="#/project">Project Station</a>
      <a href="#/cyber">Cybertools</a>
      <a href="#/help">Help / FAQ</a>
    ;
    console.log('LESS-022 nav rendered');
  }

  function setBuildTag() {
    const el = byId('bp-build');
    if (el) { el.textContent = "ui/homepage-scaffold"; console.log('LESS-023 build tag set'); }
  }

  // Run immediately if DOM is already interactive/complete
  if (document.readyState !== 'loading') {
    ensureNav(); setBuildTag();
  }
  // And again on DOMContentLoaded
  window.addEventListener('DOMContentLoaded', () => { ensureNav(); setBuildTag(); });
})(
  // DEFAULT_HOME_HASH
  try {
    if (!location.hash || location.hash === '#/' ) { location.hash = '#/home'; }
    // Nudge the router in case it missed DOMContentLoaded
    setTimeout(() => {
      try { window.dispatchEvent(new HashChangeEvent('hashchange')); console.log('LESS-026 forced hashchange'); } catch(e){ console.warn('LESS-026 failed', e); }
    }, 120);
  } catch(e){ console.warn('LESS-026 setup failed', e); }
})();
