param(
  [switch]$SkipGuard
)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $root

# ---- Settings ----
$repo      = "$root"
$www       = Join-Path $repo "MythicCore\www"
$ts        = Get-Date -Format "yyyyMMdd-HHmmss"
$bkRoot    = Join-Path $repo "_backups"
$bkDir     = Join-Path $bkRoot "full-$ts"
$tag       = "backup/portal-lock/$ts"
$bkBranch  = "backups/portal-lock-$ts"

New-Item -ItemType Directory -Force $bkDir | Out-Null

# ---- 0) Optional guard ----
if (-not $SkipGuard) {
  Write-Host ">> Running portal guard..."
  pwsh -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\tests\Portal.UI.Guard.ps1 -Mode Local
}

# ---- 1) Track key files (in case not yet added) ----
$mustTrack = @(
  "MythicCore/www/index.html",
  "MythicCore/www/portal.standalone.html",
  "MythicCore/www/_hotfix_sw_unregister.html",
  "tests/Portal.UI.Guard.ps1",
  ".gitattributes",
  "tools/Open-Portal.ps1"
) + @(
  ".github/workflows/portal-guard.yml"
) | Where-Object { Test-Path $_ }

foreach($p in $mustTrack){
  if (-not (git ls-files --error-unmatch $p 2>$null)) {
    git add $p | Out-Null
  }
}

# ---- 2) Commit any pending changes ----
$st = (git status --porcelain).Trim()
if ($st) {
  git add -A
  git commit -m "Backup checkpoint $ts (portal lock + guard)" | Out-Null
  Write-Host ">> Committed working changes."
} else {
  Write-Host ">> No working changes to commit."
}

# ---- 3) Create tag + backup branch and push ----
# tag (ignore if exists)
if (-not (git tag --list $tag)) {
  git tag -a $tag -m "Portal lock backup $ts"
  Write-Host ">> Created tag $tag"
} else {
  Write-Host ">> Tag $tag already exists (skipping)"
}

# backup branch from HEAD (ignore if exists)
if (-not (git rev-parse --verify $bkBranch 2>$null)) {
  git branch $bkBranch | Out-Null
  Write-Host ">> Created branch $bkBranch"
} else {
  Write-Host ">> Branch $bkBranch already exists (skipping)"
}

# push current branch, tag, and backup branch
$cur = (git rev-parse --abbrev-ref HEAD).Trim()
git push origin $cur | Out-Null
git push origin $bkBranch | Out-Null
git push origin $tag | Out-Null
Write-Host ">> Pushed $cur, $bkBranch, and tag $tag to origin."

# ---- 4) Full repo bundle (portable one-file backup) ----
$bundle = Join-Path $bkDir "repo-$ts.bundle"
git bundle create $bundle --all
git bundle verify $bundle | Out-Null
Write-Host ">> Wrote bundle: $bundle"

# ---- 5) Zip snapshots (workspace without .git; plus webroot) ----
$wsZip  = Join-Path $bkDir "workspace-$ts.zip"
$wwwZip = Join-Path $bkDir "www-$ts.zip"

# Workspace (exclude .git)
$items = Get-ChildItem -Force -LiteralPath $repo | Where-Object { $_.Name -ne ".git" }
Compress-Archive -Path $items.FullName -DestinationPath $wsZip -CompressionLevel Optimal

# Webroot
if (Test-Path $www) {
  Compress-Archive -Path (Join-Path $www "*") -DestinationPath $wwwZip -CompressionLevel Optimal
}

# ---- 6) Legacy fingerprint scan (for audit) ----
$legacyPat = 'runner\.css|xp[-_]?panel\.js|XP\s+—\s+Today|XP Dev Controls|Osirisborn\s+—\s+Control Panel'
$scanOut   = Join-Path $bkDir "LegacyScan-$ts.txt"

"Legacy scan $(Get-Date -Format s)" | Set-Content $scanOut -Encoding UTF8
"`n=== Repo index.html ===" | Add-Content $scanOut
Select-String -Path (Join-Path $www "index.html") -Pattern $legacyPat -SimpleMatch -AllMatches -ErrorAction SilentlyContinue |
  ForEach-Object { "$($_.Path):$($_.LineNumber): $($_.Line.Trim())" } | Add-Content $scanOut

"`n=== Webroot ===" | Add-Content $scanOut
Select-String -Path (Join-Path $www "*") -Pattern $legacyPat -SimpleMatch -AllMatches -ErrorAction SilentlyContinue |
  ForEach-Object { "$($_.Path):$($_.LineNumber): $($_.Line.Trim())" } | Add-Content $scanOut

# ---- 7) Checksums for artifacts ----
$hashFile = Join-Path $bkDir "checksums-$ts.txt"
Get-FileHash $bundle | ForEach-Object { "$($_.Algorithm)  $($_.Hash)  $(Split-Path $_.Path -Leaf)" } | Set-Content $hashFile
Get-FileHash $wsZip  | ForEach-Object { "$($_.Algorithm)  $($_.Hash)  $(Split-Path $_.Path -Leaf)" } | Add-Content $hashFile
if (Test-Path $wwwZip) {
  Get-FileHash $wwwZip | ForEach-Object { "$($_.Algorithm)  $($_.Hash)  $(Split-Path $_.Path -Leaf)" } | Add-Content $hashFile
}

# ---- 8) Final summary ----
Write-Host ""
Write-Host "=== Backup complete ==="
Write-Host "Folder: $bkDir"
Write-Host " - Bundle:      $bundle"
Write-Host " - Workspace:   $wsZip"
Write-Host " - Webroot:     $wwwZip"
Write-Host " - Legacy scan: $scanOut"
Write-Host " - Checksums:   $hashFile"
Write-Host "GitHub: pushed branch '$bkBranch' and tag '$tag'."
